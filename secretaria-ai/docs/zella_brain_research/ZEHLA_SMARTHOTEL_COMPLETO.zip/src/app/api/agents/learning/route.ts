import { NextResponse } from 'next/server';
import { getTrainingProfiles } from '@/lib/agents/training-profiles';

export async function GET() {
  const profiles = getTrainingProfiles();
  return NextResponse.json(profiles);
}

export async function POST(request: Request) {
  const body = await request.json();
  const { action, agentId, documentTitle } = body;

  if (action === 'trigger_training') {
    return NextResponse.json({
      status: 'training_initiated',
      agentId,
      message: `Treinamento iniciado para agente ${agentId}`,
      estimatedTime: '2-5 minutos',
    });
  }

  if (action === 'ingest_document') {
    return NextResponse.json({
      status: 'ingestion_started',
      agentId,
      documentTitle,
      message: `Documento "${documentTitle}" sendo processado pelo agente ${agentId}`,
    });
  }

  if (action === 'reset_agent') {
    return NextResponse.json({
      status: 'reset_initiated',
      agentId,
      message: `Reset de aprendizado iniciado para agente ${agentId}`,
    });
  }

  return NextResponse.json({ error: 'Ação inválida' }, { status: 400 });
}
