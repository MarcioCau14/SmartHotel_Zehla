import { NextResponse } from 'next/server';
import { terminalMessages } from '@/lib/store';

export async function GET() {
  return NextResponse.json(terminalMessages);
}
