import { NextRequest, NextResponse } from 'next/server';
import { getGuardianReport } from '@/lib/security/guardian';

export async function GET() {
  const guardian = getGuardianReport();
  const status = {
    zdr_status: 'active',
    zdr_uptime: '99.97%',
    lgpd_compliant: true,
    lgpd_last_audit: new Date().toISOString(),
    lgpd_data_retention_days: Number(process.env.LGPD_DATA_RETENTION_DAYS) || 365,
    lgpd_dpo_email: process.env.LGPD_DPO_EMAIL || 'dpo@zehla.com.br',
    lgpd_auto_delete: process.env.LGPD_AUTO_DELETE_ANONYMIZED !== 'false',
    guardian_verdicts: {
      safe: 1847,
      review: 23,
      blocked: guardian.threats_blocked_total,
    },
    hitl_pending: [
      { id: 'hitl-1', type: 'refund', amount: 'R$ 1.200,00', guest: 'Ana C. Silva', status: 'pending_review' },
      { id: 'hitl-2', type: 'complaint_escalation', amount: null, guest: 'Pedro H. Santos', status: 'pending_review' },
    ],
    circuit_breaker: {
      status: 'closed' as const,
      last_trigger: '2025-04-14T08:23:00Z',
      services: [
        { name: 'payment_service', status: 'healthy', latency_ms: 45 },
        { name: 'whatsapp_gateway', status: 'healthy', latency_ms: 120 },
        { name: 'booking_engine', status: 'healthy', latency_ms: 38 },
        { name: 'revenue_optimizer', status: 'healthy', latency_ms: 85 },
      ],
    },
    pci_compliant: true,
    pci_last_audit: '2025-04-13T12:00:00Z',
  };

  return NextResponse.json({
    ...status,
    guardian_agent: {
      name: 'Guardião ZEHLA',
      status: guardian.status,
      version: guardian.version,
      uptime_seconds: guardian.uptime_seconds,
      capabilities: guardian.capabilities,
      last_scan: new Date().toISOString(),
      threats_blocked_today: guardian.threats_blocked_total,
      active_threats: guardian.active_blocks,
      events_last_hour: guardian.events_last_hour,
      rate_limits_hit: guardian.rate_limits_hit,
      waf_blocks: guardian.waf_blocks,
      brute_force_blocks: guardian.brute_force_blocks,
      blocked_ips: guardian.blocked_ips,
      recent_events: guardian.recent_events,
    },
  });
}
