import { NextResponse } from 'next/server';
import { properties } from '@/lib/store';

export async function GET() {
  return NextResponse.json(properties);
}
