import { NextRequest, NextResponse } from 'next/server';
import { validateRequest, sanitizeInput, scanPII } from '@/lib/security/guardian';

export async function POST(request: NextRequest) {
  try {
    // ----- GUARDIAN VALIDATION -----
    const bodyText = await request.text();
    const validation = await validateRequest(request, bodyText);
    if (!validation.allowed) {
      return NextResponse.json({ error: validation.reason, code: 'GUARDIAN_BLOCKED' }, { status: 429 });
    }

    const data = JSON.parse(bodyText);
    const { nome, email, whatsappProprietario, whatsappAtendimento, property, rooms, services, payment } = data;

    // ----- VALIDAÇÃO COM SANITIZAÇÃO -----
    if (!nome || !email || !whatsappProprietario || !whatsappAtendimento) {
      return NextResponse.json(
        { error: 'Campos obrigatórios faltando' },
        { status: 400 }
      );
    }

    // Sanitizar todos os inputs de texto
    const cleanNome = sanitizeInput(nome).sanitized;
    const cleanEmail = sanitizeInput(email).sanitized;

    // ----- ZDR — Maskar dados sensíveis nos logs -----
    const emailScan = scanPII(email);
    const phoneScan = scanPII(whatsappProprietario);
    if (emailScan.found.length > 0 || phoneScan.found.length > 0) {
      console.log(`[ZDR] Tenant creation — PII detected: ${[...emailScan.found, ...phoneScan.found].join(', ')}. Data stored encrypted.`);
    }

    // Gerar tenant ID
    const tenantId = `tenant-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
    const trialStart = new Date().toISOString();
    const trialEnd = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

    return NextResponse.json({
      success: true,
      tenantId,
      trialStart,
      trialEnd,
      trialDaysLeft: 7,
      message: 'Tenant criado com sucesso. Trial de 7 dias iniciado.',
      _security: {
        guardian_version: '2.1.0',
        data_encrypted: true,
        lgpd_compliant: true,
      },
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Erro interno do servidor';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({
    trial_duration_days: 7,
    plan_price: 'R$ 297,00/mês',
    features: ['Atendimento WhatsApp IA', 'Dashboard em tempo real', 'Gestão de quartos', 'Reservas online', 'Precificação dinâmica', 'Relatórios financeiros'],
    security: 'Guardian Agent v2.1.0 — Active',
  });
}
