import { NextResponse } from 'next/server';
import { reservations } from '@/lib/store';
import type { ReservationStatus } from '@/lib/store';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get('status');
  const filtered = status ? reservations.filter(r => r.status === status) : reservations;
  return NextResponse.json(filtered);
}

export async function POST(request: Request) {
  const body = await request.json();
  const newRes = {
    id: `res-${String(reservations.length + 1).padStart(3, '0')}`,
    guestName: body.guestName || 'Novo Hóspede',
    guestEmail: body.guestEmail || 'email@example.com',
    guestPhone: body.guestPhone || '(00) 00000-0000',
    roomNumber: body.roomNumber || '101',
    roomType: body.roomType || 'Standard',
    checkIn: body.checkIn || '2025-04-20',
    checkOut: body.checkOut || '2025-04-23',
    status: 'PENDING' as ReservationStatus,
    totalAmount: body.totalAmount || 900,
    propertyId: body.propertyId || 'prop-1',
    createdAt: new Date().toISOString(),
  };
  reservations.push(newRes);
  return NextResponse.json(newRes, { status: 201 });
}

export async function PATCH(request: Request) {
  const body = await request.json();
  const { id, status } = body;
  const res = reservations.find(r => r.id === id);
  if (!res) return NextResponse.json({ error: 'Reserva não encontrada' }, { status: 404 });
  if (status) res.status = status as ReservationStatus;
  return NextResponse.json(res);
}
