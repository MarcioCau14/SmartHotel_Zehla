import { NextResponse } from 'next/server';
import { getRevenueKPIs } from '@/lib/store';

export async function GET() {
  return NextResponse.json(getRevenueKPIs());
}
