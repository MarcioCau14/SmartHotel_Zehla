'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft,
  Command,
  Brain,
  Terminal,
  Bot,
  Building2,
  Megaphone,
  CreditCard,
  MessageSquare,
  Plug,
  Shield,
  Eye,
  Cpu,
  BarChart3,
  TrendingUp,
  Activity,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Loader2,
  Zap,
  Hash,
  Gauge,
  Wifi,
  Database,
  Server,
  Lock,
  FileCheck,
} from 'lucide-react';

// Dashboard components to reuse
import { TerminalPanel } from '@/components/dashboard/TerminalPanel';
import { CognitivePanel } from '@/components/dashboard/CognitivePanel';
import { MarketingLeads } from '@/components/dashboard/MarketingLeads';
import { WhatsAppPanel } from '@/components/dashboard/WhatsAppPanel';
import { APIStatus } from '@/components/dashboard/APIStatus';
import { PaymentPanel } from '@/components/dashboard/PaymentPanel';
import { SystemStatusBar } from '@/components/dashboard/SystemStatusBar';

// ZCC components to reuse
import { SwarmOverview } from '@/components/zcc/SwarmOverview';
import { TenantManagement } from '@/components/zcc/TenantManagement';
import { FintechHub } from '@/components/zcc/FintechHub';
import { CognitiveObservability } from '@/components/zcc/CognitiveObservability';
import { ScaleMetrics } from '@/components/zcc/ScaleMetrics';
import { ApiKeysPanel } from '@/components/zcc/ApiKeysPanel';

import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

import type { AIAgent } from '@/lib/store';

// ===== TAB CONFIGURATION =====

type ZCCTab =
  | 'overview'
  | 'cognitivo'
  | 'terminal'
  | 'agentes'
  | 'propriedades'
  | 'marketing'
  | 'financeiro'
  | 'whatsapp'
  | 'apis'
  | 'seguranca';

interface TabConfig {
  id: ZCCTab;
  label: string;
  shortLabel: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement> & { className?: string }>;
}

const tabs: TabConfig[] = [
  { id: 'overview', label: 'Overview', shortLabel: 'Overview', icon: Eye },
  { id: 'cognitivo', label: 'Cognitivo', shortLabel: 'Cognitivo', icon: Brain },
  { id: 'terminal', label: 'Terminal', shortLabel: 'Terminal', icon: Terminal },
  { id: 'agentes', label: 'Agentes', shortLabel: 'Agentes', icon: Bot },
  { id: 'propriedades', label: 'Propriedades', shortLabel: 'Props', icon: Building2 },
  { id: 'marketing', label: 'Marketing', shortLabel: 'Marketing', icon: Megaphone },
  { id: 'financeiro', label: 'Financeiro', shortLabel: 'Financeiro', icon: CreditCard },
  { id: 'whatsapp', label: 'WhatsApp', shortLabel: 'WhatsApp', icon: MessageSquare },
  { id: 'apis', label: 'APIs', shortLabel: 'APIs', icon: Plug },
  { id: 'seguranca', label: 'Segurança', shortLabel: 'Segurança', icon: Shield },
];

// ===== AGENT MANAGEMENT TAB (Inline Component) =====

// MAL Types for inline use
interface AgentLearningState {
  agentId: string;
  status: string;
  progress: number;
  activeTask: string | null;
}

interface KnowledgeDocument {
  id: string;
  title: string;
  source: string;
  chunks: number;
  embeddingModel: string;
  ingestedAt: string;
  retentionPolicy: string;
}

interface EvolutionEntry {
  date: string;
  type: string;
  description: string;
  impact: string;
  metric?: { before: number; after: number; unit: string };
}

interface TrainingProfile {
  agentId: string;
  domain: string;
  specializations: string[];
  primaryIntents: string[];
  knowledgeBase: KnowledgeDocument[];
  learningMetrics: {
    totalInteractions: number;
    learnedPatterns: number;
    accuracyTrend: number[];
    latencyTrend: number[];
    confidenceTrend: number[];
    successRateEvolution: { period: string; rate: number }[];
    intentCoverage: { intent: string; accuracy: number; samples: number }[];
    currentEpoch: number;
    totalEpochs: number;
    loss: number;
  };
  confidenceScore: number;
  trainingStatus: string;
  lastTrained: string;
  modelVersion: number;
  evolutionLog: EvolutionEntry[];
}

// Mini Sparkline SVG Component
function MiniSparkline({ data, color, width = 120, height = 32 }: { data: number[]; color: string; width?: number; height?: number }) {
  if (data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((v - min) / range) * (height - 4) - 2;
    return `${x},${y}`;
  }).join(' ');
  return (
    <svg width={width} height={height} className="inline-block flex-shrink-0">
      <polyline fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" points={points} />
    </svg>
  );
}

// Mini Bar Chart SVG Component
function MiniBarChart({ data, width = 280, height = 48 }: { data: { period: string; rate: number }[]; width?: number; height?: number }) {
  const barWidth = Math.max(4, (width / data.length) - 4);
  const maxRate = 100;
  return (
    <svg width={width} height={height} className="inline-block flex-shrink-0">
      {data.map((d, i) => {
        const barHeight = ((d.rate / maxRate) * (height - 14));
        const x = i * (barWidth + 4) + 2;
        const y = height - 10 - barHeight;
        const opacity = 0.4 + (i / data.length) * 0.6;
        return (
          <g key={i}>
            <rect x={x} y={y} width={barWidth} height={barHeight} rx={2} fill={`rgba(16, 185, 129, ${opacity})`} />
            <text x={x + barWidth / 2} y={height - 1} textAnchor="middle" fill="rgba(163,163,163,0.6)" fontSize="7" fontFamily="monospace">{d.period}</text>
          </g>
        );
      })}
    </svg>
  );
}

function AgentManagementPanel() {
  const [agents, setAgents] = useState<AIAgent[]>([]);
  const [profiles, setProfiles] = useState<TrainingProfile[]>([]);
  const [trainingStatuses, setTrainingStatuses] = useState<AgentLearningState[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedAgent, setExpandedAgent] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  useEffect(() => {
    Promise.all([
      fetch('/api/agents').then((r) => r.json()).catch(() => []),
      fetch('/api/agents/learning').then((r) => r.json()).catch(() => []),
      fetch('/api/agents/training/status').then((r) => r.json()).catch(() => []),
    ]).then(([agentData, learningData, statusData]) => {
      setAgents(agentData);
      setProfiles(learningData);
      setTrainingStatuses(statusData);
      setLoading(false);
    });
  }, []);

  // Match agent icons from store to profiles
  const getAgentIcon = (agentId: string) => agents.find((a) => a.id === agentId)?.icon ?? '🤖';
  const getAgentName = (agentId: string) => agents.find((a) => a.id === agentId)?.name ?? agentId;
  const getAgentRole = (agentId: string) => agents.find((a) => a.id === agentId)?.role ?? '';
  const getStatusInfo = (agentId: string) => trainingStatuses.find((s) => s.agentId === agentId);

  // Fleet ML KPIs
  const totalAgents = profiles.length;
  const readyAgents = profiles.filter((p) => p.trainingStatus === 'ready').length;
  const trainingAgents = profiles.filter((p) => p.trainingStatus === 'training' || p.trainingStatus === 'learning').length;
  const totalPatterns = profiles.reduce((s, p) => s + p.learningMetrics.learnedPatterns, 0);
  const avgConfidence = profiles.length > 0 ? (profiles.reduce((s, p) => s + p.confidenceScore, 0) / profiles.length) : 0;
  const totalIntents = profiles.reduce((s, p) => s + p.learningMetrics.intentCoverage.length, 0);
  const totalDocs = profiles.reduce((s, p) => s + p.knowledgeBase.length, 0);
  const avgEpoch = profiles.length > 0 ? Math.round(profiles.reduce((s, p) => s + p.learningMetrics.currentEpoch, 0) / profiles.length) : 0;

  const statusColors: Record<string, string> = {
    ready: 'bg-emerald-500/20 text-emerald-400',
    training: 'bg-amber-500/20 text-amber-400',
    learning: 'bg-purple-500/20 text-purple-400',
    idle: 'bg-neutral-500/20 text-neutral-400',
    deploying: 'bg-cyan-500/20 text-cyan-400',
  };

  const statusLabels: Record<string, string> = {
    ready: 'READY',
    training: 'TRAINING',
    learning: 'LEARNING',
    idle: 'IDLE',
    deploying: 'DEPLOYING',
  };

  const impactColors: Record<string, string> = {
    low: 'text-neutral-500',
    medium: 'text-amber-400',
    high: 'text-emerald-400',
    critical: 'text-purple-400',
  };

  const sourceLabels: Record<string, string> = {
    pousada_docs: '📋 Docs Pousada',
    real_world: '🌍 Mundo Real',
    system_generated: '⚙️ Sistema',
    uploaded: '📤 Upload',
  };

  const evolutionIcons: Record<string, string> = {
    pattern_learned: '🧬',
    intent_refined: '🎯',
    model_updated: '🔄',
    knowledge_expanded: '📖',
    confidence_lock: '🔒',
    document_ingested: '📥',
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-xl" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* ===== Section A: Fleet ML Overview (KPIs) ===== */}
      <div className="glass-card p-5 border border-purple-500/10 bg-purple-500/[0.02]">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-neutral-300 flex items-center gap-2">
            <Brain className="w-4 h-4 text-purple-400" />
            MAL — Malha de Aprendizado Agêntica
            <Badge variant="outline" className="border-purple-500/30 text-purple-400 text-[10px]">Fleet ML</Badge>
          </h3>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-white/10 text-neutral-200' : 'text-neutral-500 hover:text-neutral-300'}`}
              aria-label="Grid view"
            >
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="0.5" y="0.5" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1"/><rect x="8.5" y="0.5" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1"/><rect x="0.5" y="8.5" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1"/><rect x="8.5" y="8.5" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1"/></svg>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-white/10 text-neutral-200' : 'text-neutral-500 hover:text-neutral-300'}`}
              aria-label="List view"
            >
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="0.5" y="1" width="13" height="2.5" rx="1" stroke="currentColor" strokeWidth="1"/><rect x="0.5" y="5.75" width="13" height="2.5" rx="1" stroke="currentColor" strokeWidth="1"/><rect x="0.5" y="10.5" width="13" height="2.5" rx="1" stroke="currentColor" strokeWidth="1"/></svg>
            </button>
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {[
            { label: 'Total Agentes', value: totalAgents, color: 'text-purple-400' },
            { label: 'Agentes Ready', value: readyAgents, color: 'text-emerald-400' },
            { label: 'Em Treinamento', value: trainingAgents, color: 'text-amber-400' },
            { label: 'Padrões Aprendidos', value: totalPatterns.toLocaleString('pt-BR'), color: 'text-cyan-400' },
            { label: 'Confiança Média', value: `${(avgConfidence * 100).toFixed(1)}%`, color: 'text-emerald-400' },
            { label: 'Intenções Cobertas', value: totalIntents, color: 'text-neutral-300' },
            { label: 'Base de Conhecimento', value: `${totalDocs} docs`, color: 'text-neutral-300' },
            { label: 'Epoch Atual', value: `${avgEpoch}/50`, color: 'text-purple-400' },
          ].map((item, i) => (
            <div key={i} className="bg-white/[0.02] rounded-lg p-3">
              <div className="text-lg font-bold font-mono {item.color}" style={{ color: 'inherit' }}>
                <span className={item.color}>{item.value}</span>
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">{item.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ===== Section B: Agent Training Cards ===== */}
      <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 gap-4' : 'space-y-3'}>
        {profiles.map((profile) => {
          const icon = getAgentIcon(profile.agentId);
          const name = getAgentName(profile.agentId);
          const role = getAgentRole(profile.agentId);
          const status = getStatusInfo(profile.agentId);
          const isExpanded = expandedAgent === profile.agentId;
          const isLocked = profile.confidenceScore >= 0.90;
          const confidenceColor = profile.confidenceScore >= 0.90 ? '#10B981' : profile.confidenceScore >= 0.80 ? '#F59E0B' : '#EF4444';
          const lastAccuracy = profile.learningMetrics.accuracyTrend[profile.learningMetrics.accuracyTrend.length - 1] ?? 0;

          return (
            <motion.div
              key={profile.agentId}
              layout
              className={`glass-card overflow-hidden transition-all ${isExpanded ? 'border-purple-500/20' : ''}`}
            >
              {/* Card Header */}
              <div className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{icon}</span>
                    <div>
                      <div className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
                        {name}
                        <Badge className={`border-0 text-[9px] ${statusColors[profile.trainingStatus] || statusColors.idle}`}>
                          {statusLabels[profile.trainingStatus] || profile.trainingStatus.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="text-[10px] text-neutral-500">{role}</div>
                      <div className="text-[9px] text-neutral-600 font-mono mt-0.5">{profile.domain}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {isLocked && (
                      <Badge className="border-0 text-[9px] bg-emerald-500/20 text-emerald-400">
                        <Lock className="w-2.5 h-2.5 mr-0.5" /> LOCKED
                      </Badge>
                    )}
                    <Badge variant="outline" className="border-white/10 text-neutral-500 text-[9px]">
                      v{profile.modelVersion}
                    </Badge>
                  </div>
                </div>

                {/* Confidence Bar */}
                <div className="mb-3">
                  <div className="flex items-center justify-between text-[10px] mb-1">
                    <span className="text-neutral-500">Confiança (KL Divergence)</span>
                    <span className="font-mono font-bold" style={{ color: confidenceColor }}>
                      {(profile.confidenceScore * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="w-full bg-white/5 rounded-full h-2">
                    <motion.div
                      className="h-2 rounded-full"
                      style={{ backgroundColor: confidenceColor }}
                      initial={{ width: 0 }}
                      animate={{ width: `${profile.confidenceScore * 100}%` }}
                      transition={{ duration: 0.8, ease: 'easeOut' }}
                    />
                  </div>
                </div>

                {/* Training Progress (if active) */}
                {(profile.trainingStatus === 'training' || profile.trainingStatus === 'learning') && status && status.progress < 100 && (
                  <div className="mb-3">
                    <div className="flex items-center justify-between text-[10px] mb-1">
                      <span className="text-neutral-500 flex items-center gap-1">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        {status.activeTask}
                      </span>
                      <span className="font-mono text-amber-400">{status.progress}%</span>
                    </div>
                    <div className="w-full bg-white/5 rounded-full h-1.5">
                      <motion.div
                        className="h-1.5 rounded-full bg-gradient-to-r from-amber-500 to-emerald-500"
                        initial={{ width: 0 }}
                        animate={{ width: `${status.progress}%` }}
                        transition={{ duration: 1, ease: 'easeOut' }}
                      />
                    </div>
                  </div>
                )}

                {/* Quick Stats */}
                <div className="grid grid-cols-3 gap-2 mb-3">
                  <div className="bg-white/[0.02] rounded-lg p-2 text-center">
                    <div className="text-xs font-bold text-emerald-400 font-mono">{profile.learningMetrics.learnedPatterns}</div>
                    <div className="text-[9px] text-neutral-600">Padrões</div>
                  </div>
                  <div className="bg-white/[0.02] rounded-lg p-2 text-center">
                    <div className="text-xs font-bold text-neutral-300 font-mono">{profile.learningMetrics.totalInteractions.toLocaleString()}</div>
                    <div className="text-[9px] text-neutral-600">Interações</div>
                  </div>
                  <div className="bg-white/[0.02] rounded-lg p-2 text-center">
                    <div className="text-xs font-bold text-cyan-400 font-mono">{profile.knowledgeBase.length}</div>
                    <div className="text-[9px] text-neutral-600">Docs</div>
                  </div>
                </div>

                {/* Accuracy Sparkline */}
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[10px] text-neutral-500">Tendência de Acurácia (30d)</div>
                  <div className="text-[10px] font-mono text-emerald-400">{(lastAccuracy * 100).toFixed(1)}%</div>
                </div>
                <div className="flex justify-center mb-3">
                  <MiniSparkline data={profile.learningMetrics.accuracyTrend} color="#10B981" width={240} height={36} />
                </div>

                {/* Top 5 Intents */}
                <div className="space-y-1 mb-3">
                  <div className="text-[10px] text-neutral-500 mb-1">Coverage de Intenções (Top 5)</div>
                  {profile.learningMetrics.intentCoverage.slice(0, 5).map((intent) => (
                    <div key={intent.intent} className="flex items-center gap-2">
                      <span className="text-[10px] text-neutral-400 font-mono w-[140px] truncate">{intent.intent}</span>
                      <div className="flex-1 bg-white/5 rounded-full h-1">
                        <div
                          className="h-1 rounded-full bg-emerald-500/70"
                          style={{ width: `${intent.accuracy}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-mono text-neutral-400 w-[38px] text-right">{intent.accuracy.toFixed(1)}%</span>
                    </div>
                  ))}
                </div>

                {/* Expand Button */}
                <button
                  onClick={() => setExpandedAgent(isExpanded ? null : profile.agentId)}
                  className="w-full text-center text-[10px] text-purple-400 hover:text-purple-300 py-2 border-t border-white/5 transition-colors"
                >
                  {isExpanded ? '▲ Recolher Detalhes' : '▼ Ver Detalhes de Treinamento'}
                </button>
              </div>

              {/* Expanded Details */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="border-t border-white/5 p-4 space-y-4 zehla-scroll-modal">
                      {/* Knowledge Base */}
                      <div>
                        <div className="text-[11px] font-semibold text-neutral-300 mb-2 flex items-center gap-1.5">
                          <Database className="w-3.5 h-3.5 text-cyan-400" />
                          Base de Conhecimento ({profile.knowledgeBase.length} documentos)
                        </div>
                        <div className="space-y-1.5">
                          {profile.knowledgeBase.map((doc) => (
                            <div key={doc.id} className="flex items-center justify-between p-2 rounded-lg bg-white/[0.02]">
                              <div className="flex-1 min-w-0">
                                <div className="text-[10px] text-neutral-300 truncate">{doc.title}</div>
                                <div className="text-[9px] text-neutral-600 flex items-center gap-2 mt-0.5">
                                  <span>{sourceLabels[doc.source] || doc.source}</span>
                                  <span>•</span>
                                  <span>{doc.chunks} chunks</span>
                                  <span>•</span>
                                  <span className="font-mono">{new Date(doc.ingestedAt).toLocaleDateString('pt-BR')}</span>
                                </div>
                              </div>
                              <Badge className={`border-0 text-[8px] flex-shrink-0 ml-2 ${
                                doc.retentionPolicy === 'zdr_anonymized' ? 'bg-purple-500/15 text-purple-400' :
                                doc.retentionPolicy === 'global_pattern' ? 'bg-cyan-500/15 text-cyan-400' :
                                'bg-amber-500/15 text-amber-400'
                              }`}>
                                {doc.retentionPolicy}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Evolution Log */}
                      <div>
                        <div className="text-[11px] font-semibold text-neutral-300 mb-2 flex items-center gap-1.5">
                          <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                          Log de Evolução
                        </div>
                        <div className="space-y-1.5">
                          {profile.evolutionLog.map((entry, idx) => (
                            <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-white/[0.02]">
                              <span className="text-sm mt-0.5">{evolutionIcons[entry.type] || '📌'}</span>
                              <div className="flex-1 min-w-0">
                                <div className="text-[10px] text-neutral-300">{entry.description}</div>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <span className="text-[9px] text-neutral-600 font-mono">{new Date(entry.date).toLocaleDateString('pt-BR')}</span>
                                  <Badge className={`border-0 text-[8px] ${impactColors[entry.impact] || 'text-neutral-500'}`}>
                                    {entry.impact.toUpperCase()}
                                  </Badge>
                                  {entry.metric && (
                                    <span className="text-[9px] text-neutral-500 font-mono">
                                      {entry.metric.before}{entry.metric.unit} → {entry.metric.after}{entry.metric.unit}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Success Rate Evolution Chart */}
                      <div>
                        <div className="text-[11px] font-semibold text-neutral-300 mb-2 flex items-center gap-1.5">
                          <BarChart3 className="w-3.5 h-3.5 text-purple-400" />
                          Evolução da Taxa de Sucesso
                        </div>
                        <div className="flex justify-center p-2 bg-white/[0.02] rounded-lg">
                          <MiniBarChart data={profile.learningMetrics.successRateEvolution} width={300} height={56} />
                        </div>
                      </div>

                      {/* Training Metrics */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <div className="bg-white/[0.02] rounded-lg p-2 text-center">
                          <div className="text-[10px] text-neutral-500">Epoch</div>
                          <div className="text-sm font-bold font-mono text-purple-400">{profile.learningMetrics.currentEpoch}/{profile.learningMetrics.totalEpochs}</div>
                        </div>
                        <div className="bg-white/[0.02] rounded-lg p-2 text-center">
                          <div className="text-[10px] text-neutral-500">Loss</div>
                          <div className="text-sm font-bold font-mono text-amber-400">{profile.learningMetrics.loss.toFixed(4)}</div>
                        </div>
                        <div className="bg-white/[0.02] rounded-lg p-2 text-center">
                          <div className="text-[10px] text-neutral-500">Intents Cobertos</div>
                          <div className="text-sm font-bold font-mono text-neutral-300">{profile.learningMetrics.intentCoverage.length}</div>
                        </div>
                        <div className="bg-white/[0.02] rounded-lg p-2 text-center">
                          <div className="text-[10px] text-neutral-500">Último Treino</div>
                          <div className="text-[10px] font-mono text-neutral-300">{new Date(profile.lastTrained).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>

      {/* ===== Section C: Cross-Agent Learning (Aprendiz) ===== */}
      {profiles.length > 0 && (
        <div className="glass-card p-5 border border-purple-500/10 bg-purple-500/[0.02]">
          <h3 className="text-sm font-semibold text-neutral-300 flex items-center gap-2 mb-4">
            <span className="text-lg">📚</span>
            Cross-Agent Learning — Aprendiz Meta-Agent
            <Badge className="border-0 text-[10px] bg-purple-500/20 text-purple-400">SÍNTESE</Badge>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Knowledge Flow Visualization */}
            <div className="bg-white/[0.02] rounded-lg p-4">
              <div className="text-[10px] text-neutral-500 mb-3 font-medium">Fluxo de Conhecimento entre Agentes</div>
              <div className="flex items-center justify-center gap-1 flex-wrap">
                {profiles.filter((p) => p.agentId !== 'agent-8').map((p) => (
                  <div key={p.agentId} className="flex flex-col items-center">
                    <div className="w-10 h-10 rounded-lg bg-white/[0.04] flex items-center justify-center text-lg border border-white/5">
                      {getAgentIcon(p.agentId)}
                    </div>
                    <div className="text-[8px] text-neutral-600 mt-1 font-mono">{p.agentId}</div>
                  </div>
                ))}
                <div className="mx-1 flex flex-col items-center">
                  <svg width="20" height="2" className="my-3"><line x1="0" y1="1" x2="20" y2="1" stroke="rgba(168,85,247,0.4)" strokeWidth="1" strokeDasharray="3,2"/></svg>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center text-lg border border-purple-500/20 animate-zehla-glow">
                    📚
                  </div>
                  <div className="text-[8px] text-purple-400 mt-1 font-mono">agent-8</div>
                </div>
              </div>
              <div className="mt-3 text-center">
                <div className="text-[10px] text-neutral-400">O Aprendiz sintetiza padrões de {profiles.length - 1} agentes e {profiles.reduce((s, p) => s + p.knowledgeBase.length, 0)} documentos</div>
              </div>
            </div>

            {/* Cross-Agent Insights */}
            <div className="bg-white/[0.02] rounded-lg p-4">
              <div className="text-[10px] text-neutral-500 mb-3 font-medium">Insights Cross-Agent (Síntese em Tempo Real)</div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 p-2 rounded bg-white/[0.02]">
                  <span className="text-emerald-400 text-[10px]">✓</span>
                  <span className="text-[10px] text-neutral-300">Padrão horário pico idêntico em 4 propriedades (14h-16h)</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-white/[0.02]">
                  <span className="text-emerald-400 text-[10px]">✓</span>
                  <span className="text-[10px] text-neutral-300">12% overlap de intents entre Reservas e Recepcionista</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-white/[0.02]">
                  <span className="text-amber-400 text-[10px]">⚡</span>
                  <span className="text-[10px] text-neutral-300">Marketing precisa de 23% mais dados sazonais (gap detectado)</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-white/[0.02]">
                  <span className="text-emerald-400 text-[10px]">✓</span>
                  <span className="text-[10px] text-neutral-300">Guardião + Financeiro: pipeline LGPD 99.7% compliance</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-white/[0.02]">
                  <span className="text-purple-400 text-[10px]">🔄</span>
                  <span className="text-[10px] text-neutral-300">Otimização de latência: 5 agentes abaixo de 60ms</span>
                </div>
              </div>
              <div className="mt-3 flex items-center gap-2">
                <div className="flex-1 bg-white/5 rounded-full h-1.5">
                  <motion.div
                    className="h-1.5 rounded-full bg-gradient-to-r from-purple-500 to-emerald-500"
                    initial={{ width: 0 }}
                    animate={{ width: '82%' }}
                    transition={{ duration: 1.2, ease: 'easeOut' }}
                  />
                </div>
                <span className="text-[10px] font-mono text-purple-400">82%</span>
              </div>
              <div className="text-[9px] text-neutral-600 mt-1">Knowledge Synthesis Progress</div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Section D: MAL Controls ===== */}
      <div className="glass-card p-5">
        <h3 className="text-sm font-semibold text-neutral-300 flex items-center gap-2 mb-4">
          <Zap className="w-4 h-4 text-emerald-400" />
          Controles MAL
        </h3>
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => fetch('/api/agents/learning', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'trigger_training', agentId: 'all' }) })}
            className="px-4 py-2 rounded-lg bg-emerald-500/20 text-emerald-400 text-xs font-medium hover:bg-emerald-500/30 transition-colors flex items-center gap-2"
          >
            <Zap className="w-3.5 h-3.5" />
            Disparar Treinamento Geral
          </button>
          <button
            onClick={() => fetch('/api/agents/learning', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'ingest_document', agentId: 'all', documentTitle: 'novo-documento.pdf' }) })}
            className="px-4 py-2 rounded-lg bg-cyan-500/20 text-cyan-400 text-xs font-medium hover:bg-cyan-500/30 transition-colors flex items-center gap-2"
          >
            <Database className="w-3.5 h-3.5" />
            Ingerir Documentos
          </button>
          <button
            onClick={() => { if (confirm('Tem certeza que deseja resetar o aprendizado de todos os agentes? Esta ação não pode ser desfeita.')) { fetch('/api/agents/learning', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'reset_agent', agentId: 'all' }) }); } }}
            className="px-4 py-2 rounded-lg bg-red-500/15 text-red-400 text-xs font-medium hover:bg-red-500/25 transition-colors flex items-center gap-2"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            Resetar Aprendizado
          </button>
        </div>

        {/* Real-time Status Indicators */}
        <div className="mt-4 pt-4 border-t border-white/5">
          <div className="text-[10px] text-neutral-500 mb-2 font-medium">Status de Treinamento em Tempo Real</div>
          <div className="flex flex-wrap gap-2">
            {trainingStatuses.map((ts) => (
              <div key={ts.agentId} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/[0.02]">
                <span className="text-sm">{getAgentIcon(ts.agentId)}</span>
                <span className="text-[10px] text-neutral-400 font-mono">{getAgentName(ts.agentId)}</span>
                <span className={`w-2 h-2 rounded-full ${
                  ts.status === 'ready' ? 'bg-emerald-400' :
                  ts.status === 'training' ? 'bg-amber-400 animate-zehla-pulse' :
                  ts.status === 'learning' ? 'bg-purple-400 animate-zehla-pulse' :
                  'bg-neutral-500'
                }`} />
                {ts.status !== 'ready' && (
                  <span className="text-[10px] font-mono text-neutral-500">{ts.progress}%</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ===== SECURITY PANEL (Enhanced Inline Component) =====

function SecurityPanel() {
  const [security, setSecurity] = useState<Record<string, unknown> | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/security')
      .then((r) => r.json())
      .then((d) => {
        setSecurity(d);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const cb = security?.circuit_breaker as Record<string, unknown> | undefined;
  const services = (cb?.services as Array<Record<string, unknown>>) || [];
  const hitl = (security?.hitl_pending as Array<Record<string, unknown>>) || [];
  const verdicts = (security?.guardian_verdicts as Record<string, number>) || {};
  const guardian = security?.guardian_agent as Record<string, unknown> | undefined;
  const capabilities = (guardian?.capabilities as string[]) || [];

  return (
    <div className="space-y-6">
      {/* Guardian Anti-Hacker Agent */}
      {loading ? (
        <Skeleton className="h-64 w-full rounded-xl" />
      ) : guardian && (
        <div className="glass-card p-6 border border-purple-500/20 bg-purple-500/[0.02]">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-purple-500/10">
                <Shield className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <h3 className="font-semibold text-neutral-200 flex items-center gap-2">
                  {String(guardian.name)}
                  <Badge variant="outline" className="border-emerald-500/30 text-emerald-400 text-[10px]">
                    v{String(guardian.version)}
                  </Badge>
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">Agente de segurança avançado — Proteção em tempo real</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full animate-zehla-pulse ${guardian.status === 'active' ? 'bg-emerald-400' : 'bg-red-400'}`} />
              <Badge variant="outline" className={`border-0 text-[10px] ${guardian.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                {guardian.status === 'active' ? 'Ativo' : 'Inativo'}
              </Badge>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            <div className="bg-white/[0.02] rounded-lg p-3">
              <div className="text-[10px] text-neutral-500">Ameaças Bloqueadas Hoje</div>
              <div className="text-lg font-bold text-red-400">{Number(guardian.threats_blocked_today || 0)}</div>
            </div>
            <div className="bg-white/[0.02] rounded-lg p-3">
              <div className="text-[10px] text-neutral-500">Ameaças Ativas</div>
              <div className="text-lg font-bold text-emerald-400">{Number(guardian.active_threats || 0)}</div>
            </div>
            <div className="bg-white/[0.02] rounded-lg p-3">
              <div className="text-[10px] text-neutral-500">Último Scan</div>
              <div className="text-xs font-mono text-neutral-300">
                {guardian.last_scan
                  ? new Date(String(guardian.last_scan)).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
                  : '—'}
              </div>
            </div>
            <div className="bg-white/[0.02] rounded-lg p-3">
              <div className="text-[10px] text-neutral-500">Capacidades</div>
              <div className="text-xs font-bold text-neutral-200">{capabilities.length}</div>
            </div>
          </div>

          <div className="text-[10px] text-neutral-500 mb-2 font-medium">Capacidades do Guardião</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
            {capabilities.map((cap, i) => (
              <div key={i} className="flex items-center gap-2 p-2 rounded-lg bg-white/[0.02]">
                <Shield className="w-3 h-3 text-purple-400 flex-shrink-0" />
                <span className="text-[10px] text-neutral-400">{cap}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ZDR Shield */}
      {loading ? (
        <Skeleton className="h-48 w-full rounded-xl" />
      ) : (
        <>
          <div className="glass-card p-5">
            <h3 className="text-sm font-semibold text-neutral-300 mb-4 flex items-center gap-2">
              <Shield className="w-4 h-4 text-purple-400" />
              ZDR Shield Status
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                {
                  label: 'ZDR Status',
                  value: String(security?.zdr_status || 'unknown'),
                  ok: security?.zdr_status === 'active',
                },
                {
                  label: 'ZDR Uptime',
                  value: String((security?.zdr_uptime as string) || '—'),
                  ok: true,
                },
                {
                  label: 'LGPD Compliant',
                  value: security?.lgpd_compliant ? 'Sim' : 'Não',
                  ok: Boolean(security?.lgpd_compliant),
                },
                {
                  label: 'PCI DSS Compliant',
                  value: security?.pci_compliant ? 'Sim' : 'Não',
                  ok: Boolean(security?.pci_compliant),
                },
                {
                  label: 'Veredictos Safe',
                  value: String(verdicts.safe || 0),
                  ok: true,
                },
                {
                  label: 'Veredictos Review',
                  value: String(verdicts.review || 0),
                  ok: (verdicts.review || 0) < 50,
                },
                {
                  label: 'Veredictos Blocked',
                  value: String(verdicts.blocked || 0),
                  ok: (verdicts.blocked || 0) < 20,
                },
                {
                  label: 'Último Audit LGPD',
                  value: security?.lgpd_last_audit
                    ? new Date(String(security.lgpd_last_audit)).toLocaleDateString('pt-BR')
                    : '—',
                  ok: true,
                },
              ].map((item, i) => (
                <div key={i} className="bg-white/[0.02] rounded-lg p-3">
                  <div className="text-[10px] text-neutral-500">{item.label}</div>
                  <div className={`text-sm font-mono font-bold ${item.ok ? 'text-emerald-400' : 'text-red-400'}`}>
                    {item.value}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* HITL Pending Approvals */}
          <div className="glass-card p-5">
            <h3 className="text-sm font-semibold text-neutral-300 mb-4 flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400" />
              HITL — Aprovações Pendentes ({hitl.filter((h: Record<string, unknown>) => (h.status as string) === 'pending_review').length})
            </h3>
            <div className="space-y-2">
              {hitl.map((item: Record<string, unknown>, i: number) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.04] transition-colors">
                  <div className="flex items-center gap-3">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        (item.status as string) === 'pending_review' ? 'bg-amber-400 animate-zehla-pulse' : 'bg-emerald-400'
                      }`}
                    />
                    <div>
                      <div className="text-sm text-neutral-300">
                        {String(item.type).replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase())}
                      </div>
                      <div className="text-[10px] text-neutral-500">
                        {item.guest ? String(item.guest) : '—'}
                        {item.amount ? ` — ${String(item.amount)}` : ''}
                      </div>
                    </div>
                  </div>
                  <Badge
                    className={`border-0 text-[10px] ${
                      (item.status as string) === 'pending_review'
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'bg-emerald-500/20 text-emerald-400'
                    }`}
                  >
                    {(item.status as string) === 'pending_review' ? 'Revisar' : 'Aprovado'}
                  </Badge>
                </div>
              ))}
              {hitl.length === 0 && (
                <div className="text-center py-8 text-neutral-600 text-xs">Nenhuma aprovação pendente</div>
              )}
            </div>
          </div>

          {/* Circuit Breaker Status */}
          <div className="glass-card p-5">
            <h3 className="text-sm font-semibold text-neutral-300 mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-400" />
              Circuit Breaker
              <Badge className="border-0 text-[10px] bg-emerald-500/20 text-emerald-400 ml-auto">
                {(cb?.status as string) || 'closed'}
              </Badge>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {services.map((svc: Record<string, unknown>, i: number) => (
                <div key={i} className="bg-white/[0.02] rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] text-neutral-500 font-mono">{String(svc.name)}</span>
                    <span
                      className={`w-2 h-2 rounded-full ${
                        (svc.status as string) === 'healthy' ? 'bg-emerald-400' : 'bg-amber-400'
                      }`}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-neutral-600">Latência</span>
                    <span
                      className={`text-xs font-mono ${
                        (svc.latency_ms as number) > 200 ? 'text-amber-400' : 'text-neutral-300'
                      }`}
                    >
                      {String(svc.latency_ms)}ms
                    </span>
                  </div>
                </div>
              ))}
            </div>
            {cb?.last_trigger && (
              <div className="mt-3 text-[10px] text-neutral-600 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Último trigger:{' '}
                {new Date(String(cb.last_trigger)).toLocaleString('pt-BR')}
              </div>
            )}
          </div>

          {/* Compliance Badges */}
          <div className="glass-card p-5">
            <h3 className="text-sm font-semibold text-neutral-300 mb-4 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-cyan-400" />
              Compliance & Attestations
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: 'LGPD Compliance', value: 'PASS', details: '0 violações detectadas', ok: true },
                { label: 'PCI DSS Scan', value: 'PASS', details: 'Tokens de pagamento válidos', ok: true },
                { label: 'Sovereign Model Hash', value: 'PASS', details: 'SHA-256: 7f2d...a4b1', ok: true },
                { label: 'Data Encryption', value: 'PASS', details: 'AES-256 + TLS 1.3', ok: true },
                { label: 'Backup Status', value: 'PASS', details: 'Último: hoje 06:00', ok: true },
                { label: 'IP Whitelist', value: 'PASS', details: '3 IPs autorizadas', ok: true },
                { label: 'Rate Limiting', value: 'ACTIVE', details: '100 req/min por tenant', ok: true },
                { label: 'Audit Trail', value: 'ACTIVE', details: 'Logs últimos 90 dias', ok: true },
              ].map((item, i) => (
                <div key={i} className="bg-white/[0.02] rounded-lg p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] text-neutral-500">{item.label}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                        item.ok ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                      }`}
                    >
                      {item.value}
                    </span>
                  </div>
                  <div className="text-[10px] text-neutral-600">{item.details}</div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ===== MAIN PAGE COMPONENT =====

export default function ZCCPage() {
  const router = useRouter();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [activeTab, setActiveTab] = useState<ZCCTab>('overview');
  const [brainHealth, setBrainHealth] = useState<Record<string, unknown> | null>(null);

  // Admin login gate
  useEffect(() => {
    try {
      const adminToken = localStorage.getItem('zehla-admin-token');
      if (adminToken) {
        const payload = JSON.parse(atob(adminToken));
        if (payload.role === 'admin' && payload.exp > Date.now()) {
          setIsAdmin(true);
        } else {
          localStorage.removeItem('zehla-admin-token');
          setIsAdmin(false);
        }
      } else {
        setIsAdmin(false);
      }
    } catch {
      setIsAdmin(false);
    }
  }, []);

  // Redirect to admin login if not authenticated
  useEffect(() => {
    if (isAdmin === false) {
      router.push('/zcc-login');
    }
  }, [isAdmin, router]);

  // Load brain health (must be BEFORE any early return to respect Rules of Hooks)
  useEffect(() => {
    if (isAdmin !== true) return;
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch('/api/brain/health');
        const data = await res.json();
        if (!cancelled) setBrainHealth(data);
      } catch {
        // silent
      }
    };
    load();
    return () => {
      cancelled = true;
    };
  }, [isAdmin]);

  // Loading state while checking admin session
  if (isAdmin === null || isAdmin === false) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-sm text-neutral-500">Verificando acesso administrativo...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#0a0a0a]">
      {/* ===== TOP BAR ===== */}
      <header className="glass-strong border-b border-white/5 px-4 sm:px-6 py-3 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3 sm:gap-4">
          <button
            onClick={() => { localStorage.removeItem('zehla-admin-token'); router.push('/zcc-login'); }}
            className="text-neutral-500 hover:text-neutral-200 transition-colors p-1.5 rounded-lg hover:bg-white/5"
            aria-label="Sair do ZCC"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2">
            <Command className="w-5 h-5 text-purple-400" />
            <h1 className="font-bold text-base sm:text-lg text-neutral-100">ZEHLA Control Center</h1>
          </div>
          <Badge variant="outline" className="border-purple-500/30 text-purple-400 text-[10px] hidden sm:inline-flex">
            v2.1.0
          </Badge>
        </div>
        <button
          onClick={() => { localStorage.removeItem('zehla-admin-token'); router.push('/zcc-login'); }}
          className="text-xs text-neutral-500 hover:text-red-400 transition-colors flex items-center gap-1.5"
        >
          <span className="hidden sm:inline">Sair (Logout)</span>
          <span className="sm:hidden">Sair</span>
        </button>
      </header>

      {/* ===== TAB BAR ===== */}
      <nav className="glass-card border-b border-white/5 px-2 sm:px-4 sticky top-[57px] z-30" aria-label="ZCC Navigation">
        <div className="flex gap-0.5 overflow-x-auto zehla-scroll-x">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 sm:px-4 py-3 text-xs font-medium whitespace-nowrap transition-all border-b-2 min-w-fit ${
                  isActive
                    ? 'text-emerald-400 border-emerald-400'
                    : 'text-neutral-500 border-transparent hover:text-neutral-300 hover:border-white/10'
                }`}
                aria-selected={isActive}
                role="tab"
              >
                <Icon className="w-3.5 h-3.5 flex-shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* ===== CONTENT AREA ===== */}
      <main className="flex-1 p-4 sm:p-6 pb-14">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
          >
            {/* Tab 1: Overview */}
            {activeTab === 'overview' && brainHealth && <SwarmOverview brainHealth={brainHealth} />}
            {activeTab === 'overview' && !brainHealth && (
              <div className="space-y-4">
                <Skeleton className="h-48 w-full rounded-xl" />
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <Skeleton key={i} className="h-40 rounded-xl" />
                  ))}
                </div>
              </div>
            )}

            {/* Tab 2: Cognitivo */}
            {activeTab === 'cognitivo' && <CognitivePanel />}

            {/* Tab 3: Terminal */}
            {activeTab === 'terminal' && <TerminalPanel />}

            {/* Tab 4: Agentes */}
            {activeTab === 'agentes' && <AgentManagementPanel />}

            {/* Tab 5: Propriedades */}
            {activeTab === 'propriedades' && <TenantManagement />}

            {/* Tab 6: Marketing */}
            {activeTab === 'marketing' && <MarketingLeads />}

            {/* Tab 7: Financeiro */}
            {activeTab === 'financeiro' && <FintechHub />}

            {/* Tab 8: WhatsApp */}
            {activeTab === 'whatsapp' && <WhatsAppPanel />}

            {/* Tab 9: APIs */}
            {activeTab === 'apis' && <ApiKeysPanel />}
            <div className="mt-6" />
            {activeTab === 'apis' && <APIStatus />}

            {/* Tab 10: Segurança */}
            {activeTab === 'seguranca' && <SecurityPanel />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* ===== BOTTOM STATUS BAR ===== */}
      <SystemStatusBar />
    </div>
  );
}
