'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  Brain,
  Zap,
  Menu,
  X,
  LogIn,
} from 'lucide-react';

// Landing Sections
import { HeroSection } from '@/components/landing/HeroSection';
import { PainPointsSection } from '@/components/landing/PainPointsSection';
import { FeaturesSection } from '@/components/landing/FeaturesSection';
import { HowItWorksSection } from '@/components/landing/HowItWorksSection';
import { TestimonialsSection } from '@/components/landing/TestimonialsSection';
import { PricingSection } from '@/components/landing/PricingSection';
import { CTASection } from '@/components/landing/CTASection';

const navLinks = [
  { label: 'Funcionalidades', href: '#funcionalidades' },
  { label: 'Preços', href: '#precos' },
  { label: 'Depoimentos', href: '#depoimentos' },
];

export default function Home() {
  const router = useRouter();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const goToTesteGratis = () => {
    setMobileMenuOpen(false);
    router.push('/teste-gratis');
  };

  const goToLogin = () => {
    setMobileMenuOpen(false);
    router.push('/login');
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* ===== NAVIGATION BAR ===== */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'glass-strong border-b border-white/5 shadow-lg shadow-black/20'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center group-hover:bg-emerald-500/20 transition-colors">
              <Brain className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg text-neutral-100 leading-none">
                ZEHLA
              </span>
              <span className="text-[10px] text-neutral-500 leading-none">
                SmartHotel
              </span>
            </div>
          </div>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavClick(link.href)}
                className="text-sm text-neutral-400 hover:text-neutral-200 transition-colors"
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Desktop CTAs */}
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={goToLogin}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-sm text-neutral-400 hover:text-neutral-200 transition-colors rounded-lg hover:bg-white/5"
            >
              <LogIn className="w-4 h-4" />
              Entrar
            </button>
            <button
              onClick={goToTesteGratis}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold rounded-lg transition-colors shadow-lg shadow-emerald-500/20 cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5" />
              Testar Grátis
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-neutral-400 hover:text-neutral-200 transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden glass-strong border-t border-white/5">
            <div className="px-4 py-4 space-y-3">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="block w-full text-left px-4 py-2.5 text-sm text-neutral-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                >
                  {link.label}
                </button>
              ))}
              <div className="pt-3 border-t border-white/5 space-y-2">
                <button
                  onClick={goToLogin}
                  className="flex items-center gap-2 px-4 py-2.5 text-sm text-neutral-300 hover:text-white rounded-lg transition-colors w-full text-left"
                >
                  <LogIn className="w-4 h-4" />
                  Entrar
                </button>
                <button
                  onClick={goToTesteGratis}
                  className="flex items-center justify-center gap-2 px-4 py-3 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold rounded-lg transition-colors w-full cursor-pointer"
                >
                  <Zap className="w-4 h-4" />
                  Testar Grátis
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* ===== MAIN CONTENT ===== */}
      <main className="flex-1 pt-16">
        <HeroSection onNavigate={goToTesteGratis} />
        <PainPointsSection />
        <FeaturesSection />
        <HowItWorksSection />

        {/* Divider */}
        <div className="max-w-6xl mx-auto px-4">
          <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        </div>

        <div id="depoimentos">
          <TestimonialsSection />
        </div>

        <PricingSection onNavigate={goToTesteGratis} />
        <CTASection onNavigate={goToTesteGratis} />
      </main>

      {/* ===== FOOTER ===== */}
      <footer className="border-t border-white/5 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-8 mb-10">
            {/* Logo & description */}
            <div className="sm:col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <Brain className="w-5 h-5 text-emerald-400" />
                <span className="font-bold text-neutral-100">ZEHLA</span>
                <span className="text-xs text-neutral-500">SmartHotel</span>
              </div>
              <p className="text-sm text-neutral-500 leading-relaxed max-w-xs">
                O cérebro ZEHLA — Sistema Operacional Cognitivo para pousadas e hotéis brasileiros.
                Automação inteligente pelo ZEHLA.
              </p>
            </div>

            {/* Product */}
            <div>
              <h4 className="text-sm font-semibold text-neutral-300 mb-4">
                Produto
              </h4>
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => handleNavClick('#funcionalidades')}
                    className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors"
                  >
                    Funcionalidades
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => handleNavClick('#precos')}
                    className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors"
                  >
                    Preços
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => handleNavClick('#depoimentos')}
                    className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors"
                  >
                    Depoimentos
                  </button>
                </li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="text-sm font-semibold text-neutral-300 mb-4">
                Suporte
              </h4>
              <ul className="space-y-2">
                <li>
                  <button onClick={() => window.location.href = '/ajuda'} className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors cursor-pointer">
                    Central de Ajuda
                  </button>
                </li>
                <li>
                  <span className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors cursor-pointer">
                    Contato
                  </span>
                </li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-sm font-semibold text-neutral-300 mb-4">
                Legal
              </h4>
              <ul className="space-y-2">
                <li>
                  <button onClick={() => window.location.href = '/termos'} className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors cursor-pointer">
                    Termos de Uso
                  </button>
                </li>
                <li>
                  <button onClick={() => window.location.href = '/privacidade'} className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors cursor-pointer">
                    LGPD
                  </button>
                </li>
                <li>
                  <button onClick={() => window.location.href = '/privacidade'} className="text-sm text-neutral-500 hover:text-neutral-300 transition-colors cursor-pointer">
                    Política de Privacidade
                  </button>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom bar */}
          <div className="h-px bg-white/5 mb-6" />
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-neutral-600">
              © 2026 SMARTHOTEL / ZEHLA Technologies. Todos os direitos reservados.
            </div>
            <div className="flex items-center gap-1 text-xs text-neutral-600">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-zehla-pulse" />
              <span>Todos os sistemas operacionais</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
