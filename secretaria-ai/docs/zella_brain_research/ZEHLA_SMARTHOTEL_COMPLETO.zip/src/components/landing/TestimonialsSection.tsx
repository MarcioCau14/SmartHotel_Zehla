'use client';

import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Ricardo M.',
    property: 'Pousada Recanto das Águas',
    city: 'Paraty, RJ',
    quote:
      'Antes eu perdia pelo menos 3 reservas por semana no WhatsApp. Agora a IA responde em segundos e eu só fico com as decisões importantes.',
    rating: 5,
    initials: 'RM',
    color: 'emerald',
  },
  {
    name: 'Ana L.',
    property: 'Pousada Vila Bela',
    city: 'Gramado, RS',
    quote:
      'O mapa de quartos mudou minha vida. Antes era caixa de som, planilha e giz. Agora é tudo no celular.',
    rating: 5,
    initials: 'AL',
    color: 'purple',
  },
  {
    name: 'Carlos S.',
    property: 'Pousada Mar e Sol',
    city: 'Jericoacoara, CE',
    quote:
      'A precificação dinâmica aumentou minha receita em 22% no primeiro mês. Eu não acreditava que fosse tão simples.',
    rating: 5,
    initials: 'CS',
    color: 'amber',
  },
  {
    name: 'Fernanda R.',
    property: 'Pousada Serra Verde',
    city: 'Campos do Jordão, SP',
    quote:
      'Finalmente sei exatamente quanto estou faturando por dia. O dashboard financeiro é incrível. Melhor investimento que fiz.',
    rating: 5,
    initials: 'FR',
    color: 'rose',
  },
];

const avatarColorMap: Record<string, string> = {
  emerald: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  purple: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  amber: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  rose: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
};

export function TestimonialsSection() {
  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-center mb-16"
      >
        <h2 className="text-3xl sm:text-4xl font-bold text-neutral-100 mb-4">
          O que os donos de pousada{' '}
          <span className="gradient-text">estão dizendo</span>
        </h2>
        <p className="text-neutral-400 text-lg max-w-2xl mx-auto">
          Histórias reais de quem já transformou sua operação com o ZEHLA.
        </p>
      </motion.div>

      <div className="grid sm:grid-cols-2 gap-4 sm:gap-6">
        {testimonials.map((t, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
            className="glass-card p-6 sm:p-8 hover:border-white/10 transition-all duration-300"
          >
            {/* Quote icon */}
            <Quote className="w-8 h-8 text-emerald-500/20 mb-4" />

            {/* Stars */}
            <div className="flex gap-1 mb-4">
              {Array.from({ length: t.rating }).map((_, j) => (
                <Star
                  key={j}
                  className="w-4 h-4 text-amber-400 fill-amber-400"
                />
              ))}
            </div>

            {/* Quote text */}
            <p className="text-neutral-300 leading-relaxed mb-6 text-sm sm:text-base">
              &ldquo;{t.quote}&rdquo;
            </p>

            {/* Author */}
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-full border flex items-center justify-center text-sm font-bold ${avatarColorMap[t.color]}`}
              >
                {t.initials}
              </div>
              <div>
                <div className="text-sm font-semibold text-neutral-200">
                  {t.name}
                </div>
                <div className="text-xs text-neutral-500">
                  {t.property} • {t.city}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
