'use client';

import { motion } from 'framer-motion';
import {
  Zap,
  Check,
  MessageSquare,
  BarChart3,
  CalendarCheck,
  Megaphone,
  CreditCard,
  Shield,
} from 'lucide-react';

interface PricingSectionProps {
  onNavigate?: () => void;
}

const planFeatures = [
  { icon: MessageSquare, text: 'WhatsApp ZEHLA 24/7' },
  { icon: BarChart3, text: 'Dashboard Financeiro' },
  { icon: CalendarCheck, text: 'Gestão de Reservas' },
  { icon: Megaphone, text: 'Promoções Automáticas' },
  { icon: CreditCard, text: 'PIX & Pagamentos Integrados' },
  { icon: Shield, text: 'Suporte 24/7' },
];

export function PricingSection({ onNavigate }: PricingSectionProps) {
  return (
    <section id="precos" className="py-24 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-center mb-16"
      >
        <h2 className="text-3xl sm:text-4xl font-bold text-neutral-100 mb-4">
          Simples. Transparente.{' '}
          <span className="gradient-text">Sem surpresa.</span>
        </h2>
        <p className="text-neutral-400 text-lg max-w-2xl mx-auto">
          Um plano completo para sua pousada crescer. Sem pegadinhas.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="glass-strong rounded-2xl p-8 sm:p-12 relative overflow-hidden"
      >
        {/* Background glow */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(16,185,129,0.08),transparent_60%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,rgba(139,92,246,0.05),transparent_60%)]" />

        <div className="relative z-10">
          {/* Badge */}
          <div className="flex justify-center mb-6">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-sm text-emerald-400 font-semibold">
              <Zap className="w-3.5 h-3.5" />
              7 DIAS GRÁTIS — Sem cartão de crédito
            </span>
          </div>

          {/* Plan name & price */}
          <div className="text-center mb-8">
            <h3 className="text-2xl sm:text-3xl font-bold text-neutral-100 mb-2">
              ZEHLA Completo
            </h3>
            <div className="flex items-baseline justify-center gap-3">
              <span className="text-xl text-neutral-500 line-through">R$ 499,00</span>
              <span className="text-4xl sm:text-5xl font-bold gradient-text">
                R$ 297
              </span>
              <span className="text-neutral-400 text-lg">/mês</span>
            </div>
            <p className="text-neutral-500 text-sm mt-2">
              Tudo incluído. Sem limites. Sem surpresas.
            </p>
          </div>

          {/* Features list */}
          <div className="grid sm:grid-cols-2 gap-3 mb-10">
            {planFeatures.map((feat, i) => (
              <div
                key={i}
                className="flex items-center gap-3 text-sm text-neutral-300"
              >
                <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                  <Check className="w-4 h-4 text-emerald-400" />
                </div>
                <span>{feat.text}</span>
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="text-center">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <button
                type="button"
                onClick={onNavigate}
                className="inline-flex items-center gap-2 px-8 py-4 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold rounded-xl transition-all duration-200 shadow-lg shadow-emerald-500/25 text-lg cursor-pointer"
              >
                <Zap className="w-5 h-5" />
                Começar Teste Grátis
              </button>
            </motion.div>
            <p className="text-xs text-neutral-600 mt-4">
              Cancela quando quiser. Sem fidelidade. Sem multa.
            </p>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
