'use client';

import { motion } from 'framer-motion';
import { Brain, Zap, ChevronRight, ChevronDown, Hotel, Star, Clock } from 'lucide-react';

interface HeroSectionProps {
  onNavigate?: () => void;
}

export function HeroSection({ onNavigate }: HeroSectionProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(16,185,129,0.12),transparent_60%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,rgba(139,92,246,0.08),transparent_60%)]" />
      <div className="absolute top-20 left-1/4 w-72 h-72 bg-emerald-500/8 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-1/4 w-96 h-96 bg-purple-500/8 rounded-full blur-3xl" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/3 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-8 text-sm text-emerald-400">
            <Brain className="w-4 h-4" />
            <span>O Cérebro ZEHLA — Sistema Operacional Cognitivo para Hotelaria</span>
          </div>

          {/* H1 */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6 leading-tight">
            <span className="text-neutral-100">Sua pousada no</span>
            <br />
            <span className="gradient-text">piloto automático</span>
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg md:text-xl text-neutral-400 max-w-3xl mx-auto mb-10 leading-relaxed">
            Atendimento 24h por WhatsApp, precificação inteligente, controle total de reservas e quartos —{' '}
            <span className="text-neutral-200 font-medium">tudo automatizado pelo ZEHLA.</span>
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <button
                type="button"
                onClick={onNavigate}
                className="inline-flex items-center gap-2 px-8 py-4 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold rounded-xl transition-all duration-200 shadow-lg shadow-emerald-500/25 cursor-pointer"
              >
                <Zap className="w-5 h-5" />
                Começar Teste Grátis
                <ChevronRight className="w-4 h-4" />
              </button>
            </motion.div>

            <a
              href="#funcionalidades"
              className="inline-flex items-center gap-2 px-8 py-4 glass-card text-neutral-300 hover:text-white font-medium rounded-xl transition-all duration-200"
            >
              Ver como funciona
              <ChevronDown className="w-4 h-4" />
            </a>
          </div>

          <p className="text-xs text-neutral-600 mb-16">
            7 dias grátis • Sem cartão de crédito • Setup em 10 minutos
          </p>

          {/* Social proof */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="grid grid-cols-3 gap-4 sm:gap-6 max-w-2xl mx-auto"
          >
            {[
              { icon: Hotel, value: '150+', label: 'Pousadas Ativas' },
              { icon: Star, value: '98.7%', label: 'Satisfação' },
              { icon: Clock, value: '7 dias', label: 'Teste Grátis' },
            ].map((stat, i) => (
              <div key={i} className="glass-card p-4 sm:p-6 text-center">
                <stat.icon className="w-5 h-5 text-emerald-400 mx-auto mb-2" />
                <div className="text-xl sm:text-3xl font-bold text-emerald-400">{stat.value}</div>
                <div className="text-xs sm:text-sm text-neutral-500 mt-1">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
