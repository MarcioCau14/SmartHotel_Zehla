'use client';

import { motion } from 'framer-motion';
import {
  MessageCircleOff,
  Table,
  DollarSign,
  Clock,
  HelpCircle,
  AlertTriangle,
} from 'lucide-react';

const painPoints = [
  {
    icon: MessageCircleOff,
    title: 'Perco reservas no WhatsApp',
    description:
      'Não consigo responder rápido o suficiente e os hóspedes acabam procurando outro lugar.',
    color: 'rose',
  },
  {
    icon: Table,
    title: 'Planilhas para tudo',
    description:
      'Uso planilhas para controlar quartos, reservas, financeiro... e nada fica organizado.',
    color: 'amber',
  },
  {
    icon: DollarSign,
    title: 'Preços parados no tempo',
    description:
      'Meus preços são os mesmos o ano todo — perco dinheiro na alta temporada e fico vazio na baixa.',
    color: 'orange',
  },
  {
    icon: Clock,
    title: 'Check-in manual e demorado',
    description:
      'Meu check-in é todo manual. O hóspede chega e eu corro para arrumar tudo.',
    color: 'purple',
  },
  {
    icon: HelpCircle,
    title: 'Não sei quanto estou faturando',
    description:
      'Não tenho controle claro de receita diária, ocupação real ou custo por hóspede.',
    color: 'cyan',
  },
  {
    icon: AlertTriangle,
    title: 'Superlotação ou quartos vazios',
    description:
      'Não consigo prever a demanda. Às vezes está lotado, outras vezes sobram quartos.',
    color: 'red',
  },
];

const colorMap: Record<string, string> = {
  rose: 'text-rose-400 bg-rose-500/10 border-rose-500/20',
  amber: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  orange: 'text-orange-400 bg-orange-500/10 border-orange-500/20',
  purple: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
  cyan: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
  red: 'text-red-400 bg-red-500/10 border-red-500/20',
};

export function PainPointsSection() {
  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-center mb-16"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6 text-sm text-rose-400">
          <AlertTriangle className="w-4 h-4" />
          <span>Seja honesto...</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-bold text-neutral-100 mb-4">
          Você se identifica com alguma{' '}
          <span className="text-rose-400">dessas situações?</span>
        </h2>
        <p className="text-neutral-400 text-lg max-w-2xl mx-auto">
          Se você disse sim para pelo menos uma, o cérebro ZEHLA foi feito para resolver isso.
        </p>
      </motion.div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {painPoints.map((point, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
            className="glass-card p-6 border border-white/5 hover:border-white/10 transition-all duration-300 group"
          >
            <div
              className={`inline-flex p-3 rounded-xl ${colorMap[point.color]} mb-4`}
            >
              <point.icon className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold text-neutral-100 mb-2">
              {point.title}
            </h3>
            <p className="text-sm text-neutral-400 leading-relaxed">
              {point.description}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
