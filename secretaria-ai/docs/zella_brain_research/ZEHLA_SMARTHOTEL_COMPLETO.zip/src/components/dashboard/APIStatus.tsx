'use client';

import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Loader2, CheckCircle, XCircle, ChevronDown, ChevronUp, Activity, Zap, Globe } from 'lucide-react';

interface LLMModel {
  name: string;
  status: 'online' | 'degraded' | 'offline';
  latency_ms: number;
  success_rate: number;
  tokens_today: number;
}

interface LLMProvider {
  name: string;
  models: LLMModel[];
  type: 'gratuita' | 'paga';
  provider: string;
  rateLimit: string;
  uptime: string;
}

const initialProviders: LLMProvider[] = [
  {
    name: 'OpenAI',
    type: 'paga',
    provider: 'OpenAI Inc.',
    rateLimit: '500 req/min (Tier 1)',
    uptime: '99.98%',
    models: [
      { name: 'GPT-4o', status: 'online', latency_ms: 320, success_rate: 99.7, tokens_today: 45000 },
      { name: 'GPT-4o-mini', status: 'online', latency_ms: 180, success_rate: 99.9, tokens_today: 32000 },
    ],
  },
  {
    name: 'Anthropic',
    type: 'paga',
    provider: 'Anthropic PBC',
    rateLimit: '1000 req/min',
    uptime: '99.95%',
    models: [
      { name: 'Claude 4 Sonnet', status: 'online', latency_ms: 410, success_rate: 99.5, tokens_today: 28000 },
      { name: 'Claude 4 Haiku', status: 'degraded', latency_ms: 650, success_rate: 97.8, tokens_today: 12000 },
    ],
  },
  {
    name: 'Google',
    type: 'gratuita',
    provider: 'Google LLC',
    rateLimit: '1500 req/min',
    uptime: '99.97%',
    models: [
      { name: 'Gemini 2.5 Pro', status: 'online', latency_ms: 280, success_rate: 99.8, tokens_today: 35000 },
      { name: 'Gemini 2.5 Flash', status: 'online', latency_ms: 150, success_rate: 99.9, tokens_today: 52000 },
    ],
  },
  {
    name: 'Meta',
    type: 'gratuita',
    provider: 'Meta Platforms',
    rateLimit: 'N/A',
    uptime: '—',
    models: [
      { name: 'Llama 4 Maverick', status: 'offline', latency_ms: 0, success_rate: 0, tokens_today: 0 },
    ],
  },
  {
    name: 'z-ai-web-dev-sdk',
    type: 'gratuita',
    provider: 'ZEHLA (Incluído)',
    rateLimit: 'Sem limite',
    uptime: '99.99%',
    models: [
      { name: 'ZAI Default', status: 'online', latency_ms: 45, success_rate: 99.9, tokens_today: 156000 },
    ],
  },
];

const statusConfig = {
  online: { color: 'text-emerald-400', bg: 'bg-emerald-500/10', label: 'Ativo', badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
  degraded: { color: 'text-amber-400', bg: 'bg-amber-500/10', label: 'Degradado', badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30' },
  offline: { color: 'text-red-400', bg: 'bg-red-500/10', label: 'Inativo', badgeColor: 'bg-red-500/20 text-red-400 border-red-500/30' },
};

export function APIStatus() {
  const [providers] = useState<LLMProvider[]>(initialProviders);
  const [testing, setTesting] = useState<string | null>(null);
  const [expandedProviders, setExpandedProviders] = useState<Set<string>>(new Set(['z-ai-web-dev-sdk']));

  const handleTest = (modelKey: string) => {
    setTesting(modelKey);
    setTimeout(() => setTesting(null), 1500);
  };

  const toggleExpand = (providerName: string) => {
    setExpandedProviders(prev => {
      const next = new Set(prev);
      if (next.has(providerName)) next.delete(providerName);
      else next.add(providerName);
      return next;
    });
  };

  return (
    <div className="space-y-4">
      {/* Summary Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="glass-card p-4">
          <Globe className="w-4 h-4 text-emerald-400 mb-1.5" />
          <div className="text-lg font-bold text-neutral-200">{initialProviders.length}</div>
          <div className="text-[10px] text-neutral-500">Provedores Configurados</div>
        </div>
        <div className="glass-card p-4">
          <Activity className="w-4 h-4 text-emerald-400 mb-1.5" />
          <div className="text-lg font-bold text-emerald-400">
            {initialProviders.filter(p => p.models.some(m => m.status === 'online')).length}
          </div>
          <div className="text-[10px] text-neutral-500">Provedores Ativos</div>
        </div>
        <div className="glass-card p-4">
          <Zap className="w-4 h-4 text-purple-400 mb-1.5" />
          <div className="text-lg font-bold text-neutral-200">360K</div>
          <div className="text-[10px] text-neutral-500">Tokens Hoje (Total)</div>
        </div>
        <div className="glass-card p-4">
          <CheckCircle className="w-4 h-4 text-emerald-400 mb-1.5" />
          <div className="text-lg font-bold text-emerald-400">99.7%</div>
          <div className="text-[10px] text-neutral-500">Sucesso Geral</div>
        </div>
      </div>

      {/* Provider Cards */}
      {providers.map((provider) => {
        const isExpanded = expandedProviders.has(provider.name);
        const hasOnlineModel = provider.models.some(m => m.status === 'online');
        const totalTokens = provider.models.reduce((s, m) => s + m.tokens_today, 0);

        return (
          <div key={provider.name} className="glass-card overflow-hidden">
            {/* Provider Header */}
            <div
              className="p-4 cursor-pointer hover:bg-white/[0.02] transition-colors"
              onClick={() => toggleExpand(provider.name)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-1.5 rounded-lg ${statusConfig[provider.models[0].status].bg}`}>
                    {hasOnlineModel ? (
                      <CheckCircle className={`w-4 h-4 ${statusConfig[provider.models[0].status].color}`} />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-400" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-neutral-200">{provider.name}</span>
                      <Badge variant="outline" className={`border-0 text-[10px] ${
                        provider.type === 'gratuita'
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : 'bg-purple-500/10 text-purple-400'
                      }`}>
                        {provider.type === 'gratuita' ? 'Gratuita' : 'Paga'}
                      </Badge>
                    </div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">{provider.provider}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="hidden sm:flex items-center gap-4 text-[10px] text-neutral-500">
                    <span className="text-right">
                      <div className="text-neutral-400">Tokens Hoje</div>
                      <div className="font-mono text-neutral-300">{totalTokens.toLocaleString('pt-BR')}</div>
                    </span>
                    <span className="text-right">
                      <div className="text-neutral-400">Uptime</div>
                      <div className="font-mono text-emerald-400">{provider.uptime}</div>
                    </span>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-neutral-500" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-neutral-500" />
                  )}
                </div>
              </div>
            </div>

            {/* Expanded Details */}
            {isExpanded && (
              <div className="border-t border-white/5 p-4">
                {/* Provider Meta Info */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                  <div className="bg-white/[0.02] rounded-lg p-2.5">
                    <div className="text-[10px] text-neutral-500">Tipo</div>
                    <div className={`text-xs font-medium ${provider.type === 'gratuita' ? 'text-emerald-400' : 'text-purple-400'}`}>
                      {provider.type === 'gratuita' ? 'Gratuita' : 'Paga'}
                    </div>
                  </div>
                  <div className="bg-white/[0.02] rounded-lg p-2.5">
                    <div className="text-[10px] text-neutral-500">Rate Limit</div>
                    <div className="text-xs font-mono text-neutral-300">{provider.rateLimit}</div>
                  </div>
                  <div className="bg-white/[0.02] rounded-lg p-2.5">
                    <div className="text-[10px] text-neutral-500">Uptime</div>
                    <div className="text-xs font-mono text-emerald-400">{provider.uptime}</div>
                  </div>
                  <div className="bg-white/[0.02] rounded-lg p-2.5">
                    <div className="text-[10px] text-neutral-500">Provedor</div>
                    <div className="text-xs text-neutral-300">{provider.provider}</div>
                  </div>
                </div>

                {/* Models */}
                <div className="text-[10px] text-neutral-500 mb-2 font-medium">Modelos</div>
                <div className="space-y-2">
                  {provider.models.map((model) => {
                    const cfg = statusConfig[model.status];
                    const modelKey = `${provider.name}-${model.name}`;
                    return (
                      <div key={model.name} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.04] transition-colors">
                        <div className="flex items-center gap-3">
                          <div className={`p-1.5 rounded-lg ${cfg.bg}`}>
                            {model.status === 'online' ? (
                              <CheckCircle className={`w-4 h-4 ${cfg.color}`} />
                            ) : model.status === 'degraded' ? (
                              <CheckCircle className={`w-4 h-4 ${cfg.color}`} />
                            ) : (
                              <XCircle className={`w-4 h-4 ${cfg.color}`} />
                            )}
                          </div>
                          <div>
                            <div className="text-sm text-neutral-200">{model.name}</div>
                            <div className="text-xs text-neutral-500">{cfg.label}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs">
                          <div className="text-right hidden sm:block">
                            <div className="text-neutral-500">Latência</div>
                            <div className={`font-mono ${model.latency_ms > 500 ? 'text-amber-400' : 'text-neutral-300'}`}>
                              {model.latency_ms > 0 ? `${model.latency_ms}ms` : '—'}
                            </div>
                          </div>
                          <div className="text-right hidden sm:block">
                            <div className="text-neutral-500">Sucesso</div>
                            <div className={`font-mono ${model.success_rate >= 99 ? 'text-emerald-400' : model.success_rate > 0 ? 'text-amber-400' : 'text-neutral-600'}`}>
                              {model.success_rate > 0 ? `${model.success_rate}%` : '—'}
                            </div>
                          </div>
                          <div className="text-right hidden md:block">
                            <div className="text-neutral-500">Tokens</div>
                            <div className="font-mono text-neutral-400">{model.tokens_today > 0 ? model.tokens_today.toLocaleString('pt-BR') : '—'}</div>
                          </div>
                          <button
                            onClick={() => handleTest(modelKey)}
                            disabled={model.status === 'offline'}
                            className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 text-xs text-neutral-400 transition-colors"
                          >
                            {testing === modelKey ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              'Testar'
                            )}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
