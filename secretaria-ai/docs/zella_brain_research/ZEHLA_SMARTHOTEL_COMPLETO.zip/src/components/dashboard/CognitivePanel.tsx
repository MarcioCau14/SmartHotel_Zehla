'use client';

import { useState, useEffect } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Settings, ArrowRight } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import type { AIAgent, IntentStat } from '@/lib/store';

const sourceColors: Record<string, string> = {
  fast_path: '#10B981',
  slow_path: '#8B5CF6',
  swarm: '#F59E0B',
};

interface LLMMarketplaceItem {
  name: string;
  status: 'active' | 'free' | 'paid';
  pricing: string;
  rateLimit: string;
  description: string;
}

const llmMarketplace: LLMMarketplaceItem[] = [
  { name: 'z-ai-web-dev-sdk', status: 'active', pricing: 'Incluída no plano', rateLimit: '—', description: 'Modelo atual' },
  { name: 'Google Gemini Flash', status: 'free', pricing: '🆓 GRATUITA', rateLimit: '15 req/min', description: '' },
  { name: 'Google Gemini Pro', status: 'free', pricing: '🆓 GRATUITA (limitado)', rateLimit: '2 req/min', description: '' },
  { name: 'Groq (Llama 3)', status: 'free', pricing: '🆓 GRATUITA', rateLimit: 'Alta velocidade', description: '' },
  { name: 'OpenAI GPT-4o-mini', status: 'paid', pricing: '💰 $0.15/1M tokens', rateLimit: '', description: '' },
  { name: 'OpenAI GPT-4o', status: 'paid', pricing: '💰 $2.50/1M tokens', rateLimit: '', description: '' },
  { name: 'Anthropic Claude 3.5 Haiku', status: 'free', pricing: '🆓 GRATUITA (limitado)', rateLimit: '', description: '' },
  { name: 'Anthropic Claude 3.5 Sonnet', status: 'paid', pricing: '💰 $3/1M tokens', rateLimit: '', description: '' },
];

export function CognitivePanel() {
  const [agents, setAgents] = useState<AIAgent[]>([]);
  const [intents, setIntents] = useState<IntentStat[]>([]);
  const [health, setHealth] = useState<Record<string, unknown> | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/agents').then(r => r.json()),
      fetch('/api/brain/intents').then(r => r.json()),
      fetch('/api/brain/health').then(r => r.json()),
    ]).then(([a, i, h]) => {
      setAgents(a);
      setIntents(i);
      setHealth(h);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="glass-card p-4"><Skeleton className="h-32 w-full" /></div>
        <div className="glass-card p-4"><Skeleton className="h-64 w-full" /></div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Sovereign Model Status */}
      {health && (
        <div className="glass-card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-neutral-300">Status do Modelo Soberano</h3>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
              {String(health.gemma_engine_status)}
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <span className="text-neutral-500">Modelo</span>
              <div className="text-neutral-300 font-mono">{String(health.sovereign_model)}</div>
            </div>
            <div>
              <span className="text-neutral-500">Tokens Hoje</span>
              <div className="text-neutral-300 font-mono">{Number(health.tokens_today).toLocaleString('pt-BR')}</div>
            </div>
            <div>
              <span className="text-neutral-500">Cache Hit</span>
              <div className="text-emerald-400 font-mono">{Number(health.cache_hit_rate).toFixed(1)}%</div>
            </div>
            <div>
              <span className="text-neutral-500">Fleet Nodes</span>
              <div className="text-neutral-300 font-mono">{String(health.fleet_nodes)}</div>
            </div>
          </div>
        </div>
      )}

      {/* LLM Marketplace */}
      <div className="glass-card p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-neutral-300 flex items-center gap-2">
            <Settings className="w-4 h-4 text-purple-400" />
            LLM Marketplace — Liberdade de Migração
          </h3>
          <Badge variant="outline" className="border-emerald-500/30 text-emerald-400 text-[10px]">
            4 gratuitas disponíveis
          </Badge>
        </div>
        <div className="space-y-2">
          {llmMarketplace.map((llm) => {
            const isActive = llm.status === 'active';
            const isFree = llm.status === 'free';
            return (
              <div key={llm.name} className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                isActive ? 'bg-emerald-500/[0.05] border border-emerald-500/10' : 'bg-white/[0.02] hover:bg-white/[0.04]'
              }`}>
                <div className="flex items-center gap-3">
                  {isActive && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-zehla-pulse" />}
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-neutral-200">{llm.name}</span>
                      {isActive && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
                          Modelo atual
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className={`text-[10px] ${isFree ? 'text-emerald-400' : 'text-purple-400'}`}>
                        {llm.pricing}
                      </span>
                      {llm.rateLimit && (
                        <>
                          <span className="text-[10px] text-neutral-600">•</span>
                          <span className="text-[10px] text-neutral-500">{llm.rateLimit}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                {isActive ? (
                  <span className="text-[10px] text-emerald-400 font-medium">✅ ATIVA</span>
                ) : (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-[10px] text-neutral-400 hover:text-neutral-200 hover:bg-white/5 px-3"
                  >
                    Configurar
                    <ArrowRight className="w-3 h-3 ml-1" />
                  </Button>
                )}
              </div>
            );
          })}
        </div>
        <div className="mt-3 text-[10px] text-neutral-600 flex items-center gap-1">
          <AlertTriangle className="w-3 h-3" />
          Alterne entre LLMs a qualquer momento sem perder dados. Modelos gratuitos são ideais para começar.
        </div>
      </div>

      {/* Intent Stats Chart */}
      <div className="glass-card p-4">
        <h3 className="text-sm font-medium text-neutral-300 mb-4">Distribuição de Intents por Fonte</h3>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={intents} layout="vertical" margin={{ left: 80 }}>
            <XAxis type="number" tick={{ fill: '#737373', fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis type="category" dataKey="name" tick={{ fill: '#a3a3a3', fontSize: 10 }} axisLine={false} tickLine={false} width={75} />
            <Tooltip
              contentStyle={{ background: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: 11 }}
              labelStyle={{ color: '#a3a3a3' }}
              formatter={(value: number, name: string) => {
                if (name === 'count') return [value, 'Execuções'];
                return [value, name];
              }}
            />
            <Bar dataKey="count" radius={[0, 4, 4, 0]}>
              {intents.map((entry, index) => (
                <Cell key={index} fill={sourceColors[entry.source]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        <div className="flex gap-4 mt-3 justify-center">
          {Object.entries(sourceColors).map(([key, color]) => (
            <div key={key} className="flex items-center gap-1.5 text-xs text-neutral-500">
              <div className="w-3 h-3 rounded" style={{ backgroundColor: color }} />
              <span className="capitalize">{key.replace('_', ' ')}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Agent Fleet Grid */}
      <div>
        <h3 className="text-sm font-medium text-neutral-300 mb-4">Fleet de Agentes</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {agents.map((agent) => (
            <div key={agent.id} className="glass-card p-4 hover:bg-white/5 transition-all duration-200">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xl">{agent.icon}</span>
                <span className={`status-dot ${agent.status}`} />
              </div>
              <div className="text-sm font-semibold text-neutral-200">{agent.name}</div>
              <div className="text-[10px] text-neutral-500 mb-3">{agent.role}</div>
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Tarefas</span>
                  <span className="text-neutral-300">{agent.tasksCompleted}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Sucesso</span>
                  <span className={agent.successRate >= 99 ? 'text-emerald-400' : agent.successRate >= 97 ? 'text-amber-400' : 'text-red-400'}>
                    {agent.successRate}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Latência</span>
                  <span className="text-neutral-300">{agent.avgLatencyMs}ms</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Uptime</span>
                  <span className="text-neutral-300">{(agent.uptimeHours / 24).toFixed(0)}d</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
