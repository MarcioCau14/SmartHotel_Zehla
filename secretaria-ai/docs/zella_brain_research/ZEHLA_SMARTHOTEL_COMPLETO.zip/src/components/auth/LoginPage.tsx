'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Brain, Mail, Lock, Eye, EyeOff, Loader2, ArrowLeft, Zap } from 'lucide-react';

interface LoginPageProps {
  onBack: () => void;
  onLogin: (data: {
    tenantId: string;
    name: string;
    email: string;
    token: string;
    trialDaysLeft: number;
    isExpired: boolean;
    isWarning: boolean;
    property: { name: string; type: string; city: string; state: string; roomsCount: number } | null;
  }) => void;
  onGoToRegister: () => void;
}

export function LoginPage({ onBack, onLogin, onGoToRegister }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !senha.trim()) {
      setError('Preencha todos os campos');
      return;
    }
    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), senha }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Erro ao fazer login');
        setIsLoading(false);
        return;
      }

      // Save to localStorage
      localStorage.setItem('zehla-token', data.data.token);
      localStorage.setItem('zehla-trial-start', data.data.trialStart);
      localStorage.setItem('zehla-onboarding-complete', 'true');
      localStorage.setItem('zehla-tenant-data', JSON.stringify({
        tenantId: data.data.tenantId,
        nome: data.data.name,
        email: data.data.email,
        whatsappProprietario: data.data.phone,
        whatsappAtendimento: data.data.phoneAlt,
        plan: data.data.plan,
      }));

      onLogin({
        tenantId: data.data.tenantId,
        name: data.data.name,
        email: data.data.email,
        token: data.data.token,
        trialDaysLeft: data.data.trialDaysLeft,
        isExpired: data.data.isExpired,
        isWarning: data.data.isWarning,
        property: data.data.property,
      });
    } catch {
      setError('Erro de conexão. Verifique sua internet.');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Back button */}
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-neutral-500 hover:text-neutral-300 transition-colors mb-8 text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar ao site
        </button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6 text-sm text-emerald-400">
              <Brain className="w-4 h-4" />
              <span>ZEHLA SmartHotel</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-neutral-100 mb-2">
              Bem-vindo de volta
            </h1>
            <p className="text-neutral-400 text-sm">
              Acesse o cérebro ZEHLA da sua pousada
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="glass-card p-6 space-y-5">
            {/* Error */}
            {error && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3">
                <p className="text-red-400 text-sm">{error}</p>
              </div>
            )}

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-2">
                E-mail
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); setError(null); }}
                  placeholder="seu@email.com"
                  className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm text-neutral-100 placeholder-neutral-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500/50 transition-all"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-2">
                Senha
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={senha}
                  onChange={(e) => { setSenha(e.target.value); setError(null); }}
                  placeholder="Sua senha"
                  className="w-full pl-10 pr-10 py-3 bg-white/5 border border-white/10 rounded-xl text-sm text-neutral-100 placeholder-neutral-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500/50 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={isLoading}
              className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold rounded-xl transition-all shadow-lg shadow-emerald-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Entrando...
                </>
              ) : (
                'Entrar no ZEHLA'
              )}
            </motion.button>
          </form>

          {/* Register link */}
          <div className="text-center mt-6">
            <p className="text-sm text-neutral-500">
              Ainda não tem conta?{' '}
              <button
                onClick={onGoToRegister}
                className="text-emerald-400 hover:text-emerald-300 font-medium transition-colors"
              >
                Testar Grátis por 7 Dias
              </button>
            </p>
          </div>

          {/* Footer note */}
          <p className="text-xs text-neutral-600 text-center mt-4">
            <Zap className="w-3 h-3 inline text-emerald-500" /> ZEHLA absorve todos os custos de IA
          </p>
        </motion.div>
      </div>
    </div>
  );
}
