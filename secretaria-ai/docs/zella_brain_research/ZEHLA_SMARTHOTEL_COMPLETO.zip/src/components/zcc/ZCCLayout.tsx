'use client';

import { ArrowLeft, Command } from 'lucide-react';

interface ZCCLayoutProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onBack: () => void;
  children: React.ReactNode;
}

const tabs = [
  { id: 'overview', label: 'Overview' },
  { id: 'fintech', label: 'Fintech' },
  { id: 'tenants', label: 'Tenants' },
  { id: 'observability', label: 'Observability' },
  { id: 'metrics', label: 'Metrics' },
];

export function ZCCLayout({ activeTab, onTabChange, onBack, children }: ZCCLayoutProps) {
  return (
    <div className="min-h-screen">
      {/* Top bar */}
      <div className="glass-strong border-b border-white/5 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="text-neutral-500 hover:text-neutral-200 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Command className="w-5 h-5 text-purple-400" />
            <span className="font-bold text-lg text-neutral-100">ZEHLA Control Center</span>
          </div>
        </div>
        <span className="text-xs text-neutral-500 font-mono">v2.0.0-beta</span>
      </div>

      {/* Sub-tabs */}
      <div className="glass-card border-b border-white/5 px-4 flex gap-1 overflow-x-auto zehla-scroll-x">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`px-4 py-3 text-xs font-medium whitespace-nowrap transition-all border-b-2 ${
              activeTab === tab.id
                ? 'text-emerald-400 border-emerald-400'
                : 'text-neutral-500 border-transparent hover:text-neutral-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="p-4 sm:p-6">
        {children}
      </div>
    </div>
  );
}
