'use client';

import { useState, useEffect } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Shield, Eye, FileCheck, AlertTriangle } from 'lucide-react';

const traces = [
  { id: 't-1', service: 'ZEHLA_BRAIN', operation: 'intent_classify', latency_ms: 18, status: 'success', timestamp: '14:23:45' },
  { id: 't-2', service: 'GUARDIAN', operation: 'lgpd_check', latency_ms: 8, status: 'success', timestamp: '14:23:44' },
  { id: 't-3', service: 'ZDR', operation: 'data_route', latency_ms: 3, status: 'success', timestamp: '14:23:43' },
  { id: 't-4', service: 'EXECUTOR', operation: 'send_whatsapp', latency_ms: 120, status: 'success', timestamp: '14:23:42' },
  { id: 't-5', service: 'REVENUE', operation: 'price_optimize', latency_ms: 95, status: 'success', timestamp: '14:23:40' },
  { id: 't-6', service: 'VOICE', operation: 'audio_transcribe', latency_ms: 210, status: 'success', timestamp: '14:23:38' },
  { id: 't-7', service: 'PAYMENT', operation: 'pix_charge', latency_ms: 2800, status: 'degraded', timestamp: '14:23:35' },
  { id: 't-8', service: 'GUARDIAN', operation: 'hitl_review', latency_ms: 45, status: 'success', timestamp: '14:23:30' },
  { id: 't-9', service: 'ZEHLA_BRAIN', operation: 'swarm_dispatch', latency_ms: 156, status: 'success', timestamp: '14:23:28' },
  { id: 't-10', service: 'HOUSEKEEPING', operation: 'task_create', latency_ms: 35, status: 'success', timestamp: '14:23:25' },
];

const attestations = [
  { id: 'a-1', type: 'LGPD Compliance', result: 'PASS', details: 'Nenhuma violação detectada', tenant: 'prop-1' },
  { id: 'a-2', type: 'PCI DSS Scan', result: 'PASS', details: 'Todos tokens de pagamento válidos', tenant: 'global' },
  { id: 'a-3', type: 'Sovereign Model Hash', result: 'PASS', details: 'SHA-256 match: 7f2d...a4b1', tenant: 'global' },
  { id: 'a-4', type: 'Data Encryption', result: 'PASS', details: 'AES-256-GCM at-rest, TLS 1.3 in-transit', tenant: 'global' },
];

export function CognitiveObservability() {
  const [security, setSecurity] = useState<Record<string, unknown> | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/security')
      .then(r => r.json())
      .then(d => { setSecurity(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      {/* ZDR & Guardian Status */}
      {loading ? (
        <Skeleton className="h-40 w-full rounded-xl" />
      ) : security && (
        <div className="glass-card p-5">
          <h3 className="text-sm font-semibold text-neutral-300 mb-4 flex items-center gap-2">
            <Shield className="w-4 h-4 text-purple-400" />
            ZDR & Guardian Status
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'ZDR Uptime', value: String((security.zdr_uptime as string) || '99.97%'), ok: true },
              { label: 'Veredictos Safe', value: String(((security.guardian_verdicts as Record<string, number>).safe) || 0), ok: true },
              { label: 'HITL Pending', value: String(Array.isArray(security.hitl_pending) ? security.hitl_pending.length : 0), ok: Array.isArray(security.hitl_pending) && security.hitl_pending.length < 5 },
              { label: 'LGPD/PCI', value: security.lgpd_compliant && security.pci_compliant ? 'Compliant' : 'Non-compliant', ok: security.lgpd_compliant && security.pci_compliant },
            ].map((item, i) => (
              <div key={i} className="bg-white/[0.02] rounded-lg p-3">
                <div className="text-[10px] text-neutral-500">{item.label}</div>
                <div className={`text-sm font-mono font-bold ${item.ok ? 'text-emerald-400' : 'text-red-400'}`}>{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Trace Viewer */}
      <div className="glass-card p-5">
        <h3 className="text-sm font-semibold text-neutral-300 mb-4 flex items-center gap-2">
          <Eye className="w-4 h-4 text-cyan-400" />
          Trace Viewer — Últimas 10 Operações
        </h3>
        <div className="space-y-1.5 terminal-text">
          {traces.map((trace) => (
            <div key={trace.id} className="flex items-center gap-3 py-1.5 px-2 rounded hover:bg-white/[0.02]">
              <span className="text-[10px] text-neutral-600 font-mono w-16">{trace.timestamp}</span>
              <span className={`text-[10px] font-mono w-28 ${
                trace.service === 'ZEHLA_BRAIN' ? 'text-emerald-400' :
                trace.service === 'GUARDIAN' ? 'text-purple-400' :
                trace.service === 'ZDR' ? 'text-amber-400' :
                'text-neutral-400'
              }`}>{trace.service}</span>
              <span className="text-[10px] text-neutral-400 flex-1">{trace.operation}</span>
              <span className={`text-[10px] font-mono ${
                trace.latency_ms > 2000 ? 'text-red-400' :
                trace.latency_ms > 100 ? 'text-amber-400' :
                'text-emerald-400'
              }`}>{trace.latency_ms}ms</span>
              <span className={`w-2 h-2 rounded-full ${
                trace.status === 'success' ? 'bg-emerald-400' :
                trace.status === 'degraded' ? 'bg-amber-400' :
                'bg-red-400'
              }`} />
            </div>
          ))}
        </div>
      </div>

      {/* ZDR Attestations */}
      <div className="glass-card p-5">
        <h3 className="text-sm font-semibold text-neutral-300 mb-4 flex items-center gap-2">
          <FileCheck className="w-4 h-4 text-emerald-400" />
          ZDR Attestations
        </h3>
        <div className="space-y-2">
          {attestations.map((att) => (
            <div key={att.id} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02]">
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <div>
                  <div className="text-xs text-neutral-300">{att.type}</div>
                  <div className="text-[10px] text-neutral-500">{att.details}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[10px] text-neutral-600 font-mono">{att.tenant}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold">
                  {att.result}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Guardian Logs */}
      <div className="glass-card p-5">
        <h3 className="text-sm font-semibold text-neutral-300 mb-4 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          Guardian Logs — Últimas Ações
        </h3>
        <div className="space-y-2 terminal-text">
          {[
            { time: '14:23:45', action: 'LGPD audit passed — prop-1', level: 'info' },
            { time: '14:20:12', action: 'HITL queued: refund R$1.200,00 — Ana C. Silva', level: 'warning' },
            { time: '14:15:30', action: 'Circuit breaker check — all services healthy', level: 'info' },
            { time: '14:10:08', action: 'Rate limit: OpenAI API at 78% quota', level: 'warning' },
            { time: '14:05:22', action: 'Sovereign hash verified — 7f2d...a4b1', level: 'info' },
            { time: '13:58:11', action: 'Blocked: suspicious IP 189.x.x.x (3 failed logins)', level: 'error' },
          ].map((log, i) => (
            <div key={i} className="flex gap-3 text-xs">
              <span className="text-neutral-600 font-mono w-16">{log.time}</span>
              <span className={`w-2 h-2 rounded-full mt-1 ${
                log.level === 'info' ? 'bg-emerald-400' :
                log.level === 'warning' ? 'bg-amber-400' :
                'bg-red-400'
              }`} />
              <span className={
                log.level === 'info' ? 'text-neutral-400' :
                log.level === 'warning' ? 'text-amber-400' :
                'text-red-400'
              }>{log.action}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
