// ============================================================
// ZEHLA Security Middleware — Next.js Edge Middleware
// Executa ANTES de qualquer rota/API
// Rate Limiting | WAF | Security Headers | IP Blocking
// ============================================================

import { NextRequest, NextResponse } from 'next/server';

// ===== CONFIGURAÇÃO =====
const GUARDIAN_ENABLED = process.env.GUARDIAN_ENABLED !== 'false';
const RATE_LIMIT_MAX = Number(process.env.GUARDIAN_RATE_LIMIT_MAX) || 100;
const RATE_LIMIT_WINDOW_MS = Number(process.env.GUARDIAN_RATE_LIMIT_WINDOW_MS) || 60000;
const BLOCK_DURATION_MS = Number(process.env.GUARDIAN_BLOCK_DURATION_MS) || 900000;

// ===== ARMAZENAMENTO EDGE-COMPATÍVEL =====
// Nota: Em produção com Redis, isso seria substituído por Redis
const rateLimitMap = new Map<string, { count: number; windowStart: number; blocked: boolean; blockedUntil: number }>();
const blockedIPMap = new Map<string, number>();

// ===== WAF RULES (compactas para Edge) =====
const WAF_PATH_PATTERNS = [
  /(\.\.\/|\.\.\\)/,                   // Path Traversal
  /(UNION\s+SELECT|OR\s+1=1)/i,       // SQL Injection básico
  /(<script|javascript:)/i,            // XSS básico
  /(\$\{jndi:)/i,                     // Log4Shell
];

// ===== EXTRAIR IP =====
function getClientIP(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for');
  if (forwarded) return forwarded.split(',')[0].trim();
  const realIP = request.headers.get('x-real-ip');
  if (realIP) return realIP.trim();
  return 'unknown';
}

// ===== SECURITY HEADERS =====
function addSecurityHeaders(response: NextResponse): NextResponse {
  response.headers.set('X-Frame-Options', 'DENY');
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('X-XSS-Protection', '1; mode=block');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  response.headers.set('X-Guardian-Version', '2.1.0');
  response.headers.set('X-ZDR-Status', process.env.ZDR_ENABLED !== 'false' ? 'active' : 'disabled');
  return response;
}

// ===== MIDDLEWARE PRINCIPAL =====
export function middleware(request: NextRequest) {
  if (!GUARDIAN_ENABLED) {
    const response = NextResponse.next();
    return addSecurityHeaders(response);
  }

  const ip = getClientIP(request);
  const path = request.nextUrl.pathname;
  const now = Date.now();

  // ----- IP BLOQUEADO? -----
  const blockedUntil = blockedIPMap.get(ip);
  if (blockedUntil && blockedUntil > now) {
    const response = NextResponse.json(
      { error: 'Acesso bloqueado pelo Guardian Agent', code: 'GUARDIAN_BLOCKED' },
      { status: 403 }
    );
    response.headers.set('Retry-After', String(Math.ceil((blockedUntil - now) / 1000)));
    return addSecurityHeaders(response);
  }
  if (blockedUntil && blockedUntil <= now) {
    blockedIPMap.delete(ip);
  }

  // ----- RATE LIMITING (somente para APIs) -----
  if (path.startsWith('/api/')) {
    let entry = rateLimitMap.get(ip);
    if (!entry) {
      entry = { count: 0, windowStart: now, blocked: false, blockedUntil: 0 };
      rateLimitMap.set(ip, entry);
    }

    // Resetar janela
    if (now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
      entry.count = 0;
      entry.windowStart = now;
      entry.blocked = false;
    }

    entry.count++;
    const remaining = Math.max(0, RATE_LIMIT_MAX - entry.count);

    // Bloquear se excedeu
    if (entry.count > RATE_LIMIT_MAX) {
      entry.blocked = true;
      entry.blockedUntil = now + BLOCK_DURATION_MS;
      blockedIPMap.set(ip, entry.blockedUntil);

      const response = NextResponse.json(
        { error: 'Rate limit excedido. Tente novamente em breve.', code: 'RATE_LIMITED' },
        { status: 429 }
      );
      response.headers.set('Retry-After', String(Math.ceil(BLOCK_DURATION_MS / 1000)));
      response.headers.set('X-RateLimit-Remaining', '0');
      return addSecurityHeaders(response);
    }

    // Continuar com headers de rate limit
    const response = NextResponse.next();
    response.headers.set('X-RateLimit-Remaining', String(remaining));
    response.headers.set('X-RateLimit-Limit', String(RATE_LIMIT_MAX));
    return addSecurityHeaders(response);
  }

  // ----- WAF — Verificar path -----
  for (const pattern of WAF_PATH_PATTERNS) {
    if (pattern.test(path)) {
      blockedIPMap.set(ip, now + BLOCK_DURATION_MS);

      const response = NextResponse.json(
        { error: 'Requisição bloqueada pelo WAF', code: 'WAF_BLOCKED' },
        { status: 403 }
      );
      return addSecurityHeaders(response);
    }
  }

  // ----- PÁGINAS NORMAIS — só adicionar headers -----
  const response = NextResponse.next();
  return addSecurityHeaders(response);
}

// ===== CONFIGURAÇÃO DE ROTAS =====
export const config = {
  matcher: [
    /*
     * Aplica a todas as rotas EXCETO:
     * - Arquivos estáticos (_next/static, favicon, etc)
     * - Arquivos de imagem/fontes
     */
    '/((?!_next/static|_next/image|favicon.ico|robots.txt|logo.svg|.*\.(?:svg|png|jpg|jpeg|gif|webp|ico|woff|woff2|ttf|eot)$).*)',
  ],
};
