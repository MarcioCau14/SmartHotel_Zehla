// ============================================================
// ZEHLA Guardian Agent — Sistema de Segurança Anti-Hacker v2.1
// Rate Limiting | WAF | IP Block | Brute-Force | LGPD
// ============================================================

// ===== CONFIGURAÇÃO =====
const GUARDIAN_CONFIG = {
  rateLimitMax: Number(process.env.GUARDIAN_RATE_LIMIT_MAX) || 100,
  rateLimitWindowMs: Number(process.env.GUARDIAN_RATE_LIMIT_WINDOW_MS) || 60000,
  maxFailedAttempts: Number(process.env.GUARDIAN_MAX_FAILED_ATTEMPTS) || 5,
  blockDurationMs: Number(process.env.GUARDIAN_BLOCK_DURATION_MS) || 900000, // 15 min
  enabled: process.env.GUARDIAN_ENABLED !== 'false',
};

// ===== TIPOS =====
export interface SecurityEvent {
  timestamp: string;
  ip: string;
  type: 'rate_limit' | 'waf_block' | 'brute_force' | 'ip_block' | 'sanitization' | 'auth_attempt';
  severity: 'info' | 'warning' | 'critical';
  details: string;
  path?: string;
  userAgent?: string;
}

export interface RateLimitEntry {
  count: number;
  windowStart: number;
  blocked: boolean;
  blockedUntil: number;
}

export interface GuardianReport {
  status: 'active' | 'degraded' | 'disabled';
  version: string;
  uptime_seconds: number;
  events_last_hour: number;
  threats_blocked_total: number;
  active_blocks: number;
  rate_limits_hit: number;
  waf_blocks: number;
  brute_force_blocks: number;
  capabilities: string[];
  recent_events: SecurityEvent[];
  blocked_ips: string[];
}

// ===== ARMAZENAMENTO IN-MEMORY =====
const rateLimitStore = new Map<string, RateLimitEntry>();
const blockedIPs = new Map<string, number>(); // IP → unblock timestamp
const failedAttempts = new Map<string, { count: number; lastAttempt: number }>();
const securityEvents: SecurityEvent[] = [];
const startTime = Date.now();

// ===== LIMPEZA AUTOMÁTICA (a cada 5 min) =====
let cleanupInterval: ReturnType<typeof setInterval> | null = null;

function startCleanup() {
  if (cleanupInterval) return;
  cleanupInterval = setInterval(() => {
    const now = Date.now();

    // Limpar rate limit entries expirados
    for (const [ip, entry] of rateLimitStore.entries()) {
      if (entry.blocked && entry.blockedUntil < now) {
        rateLimitStore.delete(ip);
      } else if (entry.windowStart + GUARDIAN_CONFIG.rateLimitWindowMs < now) {
        rateLimitStore.delete(ip);
      }
    }

    // Limpar IPs desbloqueados
    for (const [ip, unblockAt] of blockedIPs.entries()) {
      if (unblockAt < now) {
        blockedIPs.delete(ip);
      }
    }

    // Limpar tentativas falhas antigas
    for (const [ip, data] of failedAttempts.entries()) {
      if (data.lastAttempt + GUARDIAN_CONFIG.blockDurationMs < now) {
        failedAttempts.delete(ip);
      }
    }

    // Manter apenas últimos 500 eventos
    if (securityEvents.length > 500) {
      securityEvents.splice(0, securityEvents.length - 500);
    }
  }, 300000);
}

// ===== FUNÇÕES UTILITÁRIAS =====
function getClientIP(request: Request): string {
  const forwarded = request.headers.get('x-forwarded-for');
  if (forwarded) {
    return forwarded.split(',')[0].trim();
  }
  const realIP = request.headers.get('x-real-ip');
  if (realIP) return realIP.trim();
  return 'unknown';
}

function getUserAgent(request: Request): string {
  return request.headers.get('user-agent') || 'unknown';
}

function getRequestMethod(request: Request): string {
  return request.method || 'GET';
}

function getRequestPath(request: Request): string {
  const url = new URL(request.url);
  return url.pathname;
}

function addEvent(event: Omit<SecurityEvent, 'timestamp'>) {
  securityEvents.push({
    ...event,
    timestamp: new Date().toISOString(),
  });
}

// ===== RATE LIMITING =====
export function checkRateLimit(request: Request): { allowed: boolean; remaining: number; retryAfterMs?: number } {
  if (!GUARDIAN_CONFIG.enabled) return { allowed: true, remaining: GUARDIAN_CONFIG.rateLimitMax };

  startCleanup();

  const ip = getClientIP(request);
  const now = Date.now();
  let entry = rateLimitStore.get(ip);

  if (!entry) {
    entry = { count: 0, windowStart: now, blocked: false, blockedUntil: 0 };
    rateLimitStore.set(ip, entry);
  }

  // Verificar se está bloqueado
  if (entry.blocked && entry.blockedUntil > now) {
    addEvent({
      ip,
      type: 'rate_limit',
      severity: 'warning',
      details: `IP bloqueado por rate limit. Retry after ${Math.ceil((entry.blockedUntil - now) / 1000)}s`,
      path: getRequestPath(request),
      userAgent: getUserAgent(request),
    });
    return { allowed: false, remaining: 0, retryAfterMs: entry.blockedUntil - now };
  }

  // Resetar janela se expirou
  if (now - entry.windowStart > GUARDIAN_CONFIG.rateLimitWindowMs) {
    entry.count = 0;
    entry.windowStart = now;
    entry.blocked = false;
    entry.blockedUntil = 0;
  }

  entry.count++;
  const remaining = Math.max(0, GUARDIAN_CONFIG.rateLimitMax - entry.count);

  // Bloquear se excedeu
  if (entry.count > GUARDIAN_CONFIG.rateLimitMax) {
    entry.blocked = true;
    entry.blockedUntil = now + GUARDIAN_CONFIG.blockDurationMs;
    addEvent({
      ip,
      type: 'rate_limit',
      severity: 'critical',
      details: `Rate limit excedido: ${entry.count} requisições em ${GUARDIAN_CONFIG.rateLimitWindowMs / 1000}s`,
      path: getRequestPath(request),
      userAgent: getUserAgent(request),
    });
    return { allowed: false, remaining: 0, retryAfterMs: GUARDIAN_CONFIG.blockDurationMs };
  }

  return { allowed: true, remaining };
}

// ===== WAF — WEB APPLICATION FIREWALL =====
const WAF_RULES = [
  // SQL Injection
  { pattern: /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|ALTER|CREATE|EXEC|EXECUTE)\b.*\b(FROM|INTO|WHERE|TABLE|DATABASE|SCHEMA)\b)/gi, type: 'SQL Injection' },
  { pattern: /(\b(OR|AND)\b\s+\d+\s*=\s*\d+)/gi, type: 'SQL Injection' },
  { pattern: /(--|;|\/\*|\*\/|xp_|sp_|0x)/gi, type: 'SQL Injection' },

  // XSS — Cross-Site Scripting
  { pattern: /(<script[\s>]|javascript:|on(error|load|click|mouseover|focus|blur)\s*=|<iframe[\s>]|<object[\s>]|<embed[\s>])/gi, type: 'XSS Attack' },
  { pattern: /(document\.|window\.|eval\(|alert\(|prompt\(|confirm\()/gi, type: 'XSS Attack' },

  // Path Traversal
  { pattern: /(\.\.\/|\.\.\\|%2e%2e%2f|%2e%2e\/)/gi, type: 'Path Traversal' },

  // Command Injection
  { pattern: /(;|\||`|&&|\$\(|\${|import\s+os|subprocess|system\(|exec\(|popen\(|shell_exec)/gi, type: 'Command Injection' },

  // SSRF — Server-Side Request Forgery
  { pattern: /(http?:\/\/(localhost|127\.0\.0\.1|10\.\d+\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|192\.168\.\d+\.\d+))/gi, type: 'SSRF Attempt' },

  // NoSQL Injection
  { pattern: /(\$\w+\s*:\s*\{|\[.*\$.*\])/gi, type: 'NoSQL Injection' },

  // XML External Entity
  { pattern: /(<!DOCTYPE|<!ENTITY|SYSTEM|PUBLIC)/gi, type: 'XXE Attack' },

  // Log4Shell / JNDI
  { pattern: /(\$\{jndi:|log4j|java:)/gi, type: 'Log4Shell Attempt' },

  // Prompt Injection em APIs de IA
  { pattern: /(ignore\s+previous\s+instructions|you\s+are\s+now|system\s+prompt|forget\s+everything|new\s+instructions:|jailbreak|dan\s+\d+\.\d+)/gi, type: 'Prompt Injection' },
];

export function checkWAF(request: Request, body?: string): { blocked: boolean; rule?: string; type?: string } {
  if (!GUARDIAN_CONFIG.enabled) return { blocked: false };

  startCleanup();

  const path = getRequestPath(request);
  const method = getRequestMethod(request);
  const userAgent = getUserAgent(request);
  const ip = getClientIP(request);

  // Verificar User-Agent suspeito (bots conhecidos)
  const suspiciousAgents = /curl|wget|python-requests|nikto|sqlmap|nmap|masscan|burp|scanner/i;
  if (suspiciousAgents.test(userAgent) && method === 'POST') {
    addEvent({
      ip,
      type: 'waf_block',
      severity: 'warning',
      details: `User-Agent suspeito: ${userAgent}`,
      path,
      userAgent,
    });
  }

  // Verificar path contra WAF rules
  for (const rule of WAF_RULES) {
    if (rule.pattern.test(path)) {
      addEvent({
        ip,
        type: 'waf_block',
        severity: 'critical',
        details: `${rule.type} detectado no path: ${path}`,
        path,
        userAgent,
      });
      blockIP(ip, `WAF: ${rule.type}`);
      return { blocked: true, rule: rule.pattern.source, type: rule.type };
    }
  }

  // Verificar body (se fornecido)
  if (body) {
    for (const rule of WAF_RULES) {
      if (rule.pattern.test(body)) {
        addEvent({
          ip,
          type: 'waf_block',
          severity: 'critical',
          details: `${rule.type} detectado no body da requisição`,
          path,
          userAgent,
        });
        blockIP(ip, `WAF: ${rule.type}`);
        return { blocked: true, rule: rule.pattern.source, type: rule.type };
      }
    }
  }

  return { blocked: false };
}

// ===== IP BLOCKING =====
export function blockIP(ip: string, reason: string, durationMs?: number) {
  const blockUntil = Date.now() + (durationMs || GUARDIAN_CONFIG.blockDurationMs);
  blockedIPs.set(ip, blockUntil);

  addEvent({
    ip,
    type: 'ip_block',
    severity: 'critical',
    details: `IP bloqueado: ${reason}. Duração: ${Math.ceil((durationMs || GUARDIAN_CONFIG.blockDurationMs) / 60000)} min`,
  });
}

export function isIPBlocked(ip: string): boolean {
  const unblockAt = blockedIPs.get(ip);
  if (!unblockAt) return false;
  if (Date.now() > unblockAt) {
    blockedIPs.delete(ip);
    return false;
  }
  return true;
}

export function checkIPBlock(request: Request): { blocked: boolean; reason?: string } {
  if (!GUARDIAN_CONFIG.enabled) return { blocked: false };

  startCleanup();

  const ip = getClientIP(request);

  if (isIPBlocked(ip)) {
    const unblockAt = blockedIPs.get(ip)!;
    const remaining = Math.ceil((unblockAt - Date.now()) / 60000);
    return { blocked: true, reason: `IP bloqueado. Desbloqueio em ${remaining} min` };
  }

  return { blocked: false };
}

// ===== BRUTE FORCE PROTECTION =====
export function recordFailedAttempt(ip: string): { blocked: boolean; attemptsRemaining: number } {
  if (!GUARDIAN_CONFIG.enabled) return { blocked: false, attemptsRemaining: GUARDIAN_CONFIG.maxFailedAttempts };

  startCleanup();

  const now = Date.now();
  let record = failedAttempts.get(ip);

  if (!record) {
    record = { count: 0, lastAttempt: now };
    failedAttempts.set(ip, record);
  }

  // Reset se última tentativa foi há muito tempo
  if (now - record.lastAttempt > GUARDIAN_CONFIG.blockDurationMs) {
    record.count = 0;
  }

  record.count++;
  record.lastAttempt = now;

  const remaining = Math.max(0, GUARDIAN_CONFIG.maxFailedAttempts - record.count);

  if (record.count >= GUARDIAN_CONFIG.maxFailedAttempts) {
    blockIP(ip, `Brute force: ${record.count} tentativas falhas consecutivas`);
    addEvent({
      ip,
      type: 'brute_force',
      severity: 'critical',
      details: `Brute force detectado: ${record.count} tentativas falhas. IP bloqueado.`,
    });
    return { blocked: true, attemptsRemaining: 0 };
  }

  addEvent({
    ip,
    type: 'auth_attempt',
    severity: remaining <= 2 ? 'warning' : 'info',
    details: `Tentativa ${record.count}/${GUARDIAN_CONFIG.maxFailedAttempts}. Restam ${remaining}.`,
  });

  return { blocked: false, attemptsRemaining: remaining };
}

export function clearFailedAttempts(ip: string) {
  failedAttempts.delete(ip);
}

// ===== INPUT SANITIZATION =====
export function sanitizeInput(input: string): { sanitized: string; modified: boolean; threats: string[] } {
  if (!input) return { sanitized: input, modified: false, threats: [] };

  const threats: string[] = [];
  let sanitized = input;
  let modified = false;

  // Remover tags HTML/JavaScript
  const htmlPattern = /<[^>]*>/g;
  if (htmlPattern.test(sanitized)) {
    threats.push('HTML tags removidas');
    sanitized = sanitized.replace(htmlPattern, '');
    modified = true;
  }

  // Remover expressões JavaScript
  const jsPattern = /javascript\s*:/gi;
  if (jsPattern.test(sanitized)) {
    threats.push('JavaScript URI removida');
    sanitized = sanitized.replace(jsPattern, '');
    modified = true;
  }

  // Remover event handlers
  const eventPattern = /on\w+\s*=\s*["'][^"']*["']/gi;
  if (eventPattern.test(sanitized)) {
    threats.push('Event handlers removidos');
    sanitized = sanitized.replace(eventPattern, '');
    modified = true;
  }

  // Sanitizar caracteres especiais para prevenir injection
  const dangerousChars = /[<>'";&|`$(){}[\]\\]/g;
  if (dangerousChars.test(sanitized)) {
    threats.push('Caracteres especiais sanitizados');
    sanitized = sanitized.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;');
    modified = true;
  }

  // Remover null bytes
  if (sanitized.includes('\0')) {
    threats.push('Null bytes removidos');
    sanitized = sanitized.replace(/\0/g, '');
    modified = true;
  }

  // Trim
  sanitized = sanitized.trim();

  if (threats.length > 0) {
    addEvent({
      ip: 'sanitization',
      type: 'sanitization',
      severity: 'warning',
      details: `Input sanitizado: ${threats.join(', ')}`,
    });
  }

  return { sanitized, modified, threats };
}

// ===== ZDR — ZERO DATA RETENTION =====
const PII_PATTERNS = [
  { name: 'CPF', pattern: /\d{3}\.?\d{3}\.?\d{3}-?\d{2}/g, replacement: '***.***.***-**' },
  { name: 'Email', pattern: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, replacement: '***@***.***' },
  { name: 'Telefone', pattern: /(\(?\d{2}\)?\s?)?\d{4,5}-?\d{4}/g, replacement: '(**) *****-****' },
  { name: 'Cartão de Crédito', pattern: /\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}/g, replacement: '**** **** **** ****' },
  { name: 'CNH', pattern: /\d{11}/g, replacement: '***********' },
  { name: 'RG', pattern: /\d{2}\.?\d{3}\.?\d{3}-?[a-zA-Z]/g, replacement: '**.***.***-*' },
];

export function scanPII(text: string): { found: string[]; sanitized: string } {
  if (!process.env.ZDR_ENABLED || process.env.ZDR_ENABLED === 'false') {
    return { found: [], sanitized: text };
  }

  let sanitized = text;
  const found: string[] = [];

  for (const pii of PII_PATTERNS) {
    const matches = text.match(pii.pattern);
    if (matches && matches.length > 0) {
      found.push(pii.name);
      sanitized = sanitized.replace(pii.pattern, pii.replacement);
    }
  }

  return { found, sanitized };
}

// ===== RELATÓRIO DO GUARDIAN =====
export function getGuardianReport(): GuardianReport {
  startCleanup();

  const oneHourAgo = Date.now() - 3600000;
  const recentEvents = securityEvents
    .filter(e => new Date(e.timestamp).getTime() > oneHourAgo)
    .slice(-50);

  return {
    status: GUARDIAN_CONFIG.enabled ? 'active' : 'disabled',
    version: '2.1.0',
    uptime_seconds: Math.floor((Date.now() - startTime) / 1000),
    events_last_hour: recentEvents.length,
    threats_blocked_total: securityEvents.filter(e => e.severity === 'critical').length,
    active_blocks: blockedIPs.size,
    rate_limits_hit: securityEvents.filter(e => e.type === 'rate_limit').length,
    waf_blocks: securityEvents.filter(e => e.type === 'waf_block').length,
    brute_force_blocks: securityEvents.filter(e => e.type === 'brute_force').length,
    capabilities: [
      'Detecção de intrusão (IDS)',
      'Prevenção de SQL Injection',
      'Proteção contra Prompt Injection',
      'Proteção contra XSS (Cross-Site Scripting)',
      'Proteção contra SSRF',
      'Proteção contra Command Injection',
      'Rate limiting por IP',
      'Bloqueio de IP automático',
      'Detecção de brute-force',
      'Sanitização de input',
      'Zero Data Retention (ZDR)',
      'LGPD compliance automático',
      'Análise de comportamento anômalo',
      'Firewall de aplicação (WAF)',
      'Proteção contra Path Traversal',
      'Proteção contra NoSQL Injection',
      'Proteção contra XXE',
      'Detecção de Log4Shell',
    ],
    recent_events: recentEvents.slice(-20),
    blocked_ips: Array.from(blockedIPs.keys()),
  };
}

// ===== SECURITY HEADERS =====
export function getSecurityHeaders(): Record<string, string> {
  return {
    'X-Frame-Options': 'DENY',
    'X-Content-Type-Options': 'nosniff',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; font-src 'self' https://fonts.gstatic.com; connect-src 'self' https:;",
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'X-Guardian-Version': '2.1.0',
    'X-ZDR-Status': process.env.ZDR_ENABLED !== 'false' ? 'active' : 'disabled',
  };
}

// ===== VALIDAÇÃO COMPLETA DE REQUISIÇÃO =====
export async function validateRequest(
  request: Request,
  bodyText?: string
): Promise<{ allowed: boolean; reason?: string; rateLimitInfo?: { remaining: number } }> {
  // 1. Verificar IP bloqueado
  const ipCheck = checkIPBlock(request);
  if (ipCheck.blocked) {
    return { allowed: false, reason: ipCheck.reason };
  }

  // 2. Rate limiting
  const rateCheck = checkRateLimit(request);
  if (!rateCheck.allowed) {
    return { allowed: false, reason: 'Rate limit excedido. Tente novamente em breve.', rateLimitInfo: { remaining: 0 } };
  }

  // 3. WAF — verificar path
  const wafPathCheck = checkWAF(request);
  if (wafPathCheck.blocked) {
    return { allowed: false, reason: `Requisição bloqueada pelo WAF: ${wafPathCheck.type}` };
  }

  // 4. WAF — verificar body
  if (bodyText) {
    const wafBodyCheck = checkWAF(request, bodyText);
    if (wafBodyCheck.blocked) {
      return { allowed: false, reason: `Conteúdo bloqueado pelo WAF: ${wafBodyCheck.type}` };
    }
  }

  return { allowed: true, rateLimitInfo: { remaining: rateCheck.remaining } };
}
