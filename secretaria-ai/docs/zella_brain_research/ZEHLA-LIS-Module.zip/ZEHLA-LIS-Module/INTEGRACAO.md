# ZEHLA LIS - Lead Intelligence System
## Guia de Integracao ao Projeto Existente

---

## VISAO GERAL

Este modulo implementa um **Mapa Cognitivo de Leads** com geolocalizacao real, 
painel de analytics, filtros e acoes de marketing (WhatsApp, E-mail, Instagram).

**Stack necessario:** Next.js 16+ (App Router), Prisma ORM, Tailwind CSS 4+

---

## ESTRUTURA DE ARQUIVOS

```
ZEHLA-LIS-Module/
├── prisma/
│   └── Lead-model.prisma          # Modelo Prisma (cole no seu schema.prisma)
├── scripts/
│   └── seed-leads.ts              # Script de seed com 37 pousadas reais
├── src/
│   ├── app/
│   │   ├── page.tsx               # Pagina principal (dynamic import SSR-safe)
│   │   └── api/leads/
│   │       ├── route.ts           # API CRUD (GET/POST/PATCH/DELETE) + filtros
│   │       ├── seed/route.ts      # API de seed via POST
│   │       └── analytics/route.ts # API de analytics agregados
│   └── components/leads/
│       └── LeadMap.tsx            # Componente principal do mapa
└── styles/
    └── globals.css                # Estilos dark theme + Leaflet overrides
```

---

## PASSO A PASSO DE INTEGRACAO

### PASSO 1 - Instalar dependencias

```bash
bun add react-leaflet leaflet @types/leaflet
# ou
npm install react-leaflet leaflet @types/leaflet
```

### PASSO 2 - Adicionar o modelo Lead ao Prisma

1. Abra seu arquivo `prisma/schema.prisma`
2. Cole o conteudo de `prisma/Lead-model.prisma` no final do arquivo
3. Rode a migracao:
```bash
bun run db:push
# ou
npx prisma db push
```

### PASSO 3 - Copiar arquivos para o projeto

Copie os arquivos mantendo a estrutura de pastas:

| Origem (neste modulo) | Destino (no seu projeto) |
|-----------------------|------------------------|
| `src/components/leads/LeadMap.tsx` | `src/components/leads/LeadMap.tsx` |
| `src/app/api/leads/route.ts` | `src/app/api/leads/route.ts` |
| `src/app/api/leads/seed/route.ts` | `src/app/api/leads/seed/route.ts` |
| `src/app/api/leads/analytics/route.ts` | `src/app/api/leads/analytics/route.ts` |
| `scripts/seed-leads.ts` | `scripts/seed-leads.ts` |

### PASSO 4 - Ajustar o import do banco de dados

Os arquivos de API usam `import { db } from '@/lib/db'`.
Se o seu projeto usa um caminho diferente, ajuste essa importacao nos 3 arquivos:
- `src/app/api/leads/route.ts`
- `src/app/api/leads/seed/route.ts`
- `src/app/api/leads/analytics/route.ts`

Exemplo: se seu Prisma client esta em `@/lib/prisma`, troque para:
```typescript
import { prisma } from '@/lib/prisma';
// e troque todas as chamadas de db.lead para prisma.lead
```

### PASSO 5 - Adicionar a pagina do mapa

Se quiser usar o mapa como pagina raiz, copie `src/app/page.tsx`.
Se preferir usar como rota separada (ex: `/leads/mapa`), renomeie para:
`src/app/leads/mapa/page.tsx` - o componente funciona como pagina independente.

### PASSO 6 - Adicionar estilos (OPCIONAL)

Se o seu projeto ja tem tema dark com Tailwind, voce pode pular este passo.
Os estilos necessarios sao apenas os overrides do Leaflet (popups, controles, markers).
Copie os blocos de comentario `/* Leaflet overrides */` do arquivo `styles/globals.css`
para o seu `globals.css` ou arquivo de estilos principal.

---

## PASSO 7 - Popular o banco com dados de exemplo

```bash
bun run scripts/seed-leads.ts
# ou
npx tsx scripts/seed-leads.ts
```

Isso vai inserir 37 pousadas reais geolocalizadas em todas as 5 regioes do Brasil.

---

## CONFIGURACOES ADAPTAVEIS

### Mudar o tile do mapa
No arquivo `LeadMap.tsx`, linha da `<TileLayer>`:
```tsx
// CARTO Dark (padrao - gratuito)
url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"

// OpenStreetMap (alternativa gratuita)
url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"

// Mapbox (requer token)
url="https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={TOKEN}"
```

### Mudar centro/zoom inicial do mapa
No arquivo `LeadMap.tsx`:
```tsx
<MapContainer
  center={[-14.235, -51.9253]}  // Lat/Lng do Brasil
  zoom={5}                       // Zoom: 5 = visao nacional
```

### Mudar cores do tema
Os marcadores SVG estao no topo do `LeadMap.tsx`. Ajuste as cores nos gradientes:
- `#f59e0b` / `#d97706` = Amarelo (padrao)
- `#ef4444` / `#dc2626` = Vermelho (hot leads)
- `#10b981` / `#059669` = Verde (convertidos)

### Threshold de score para "Hot Lead"
Padrao: score >= 85. Para mudar:
```tsx
// No arquivo LeadMap.tsx, funcao getLeadIcon:
if (scoreQual >= 85) return hotspotIcon;  // altere o valor 85
```

---

## API ENDPOINTS

### GET /api/leads
Retorna todos os leads + stats agregados.

**Query Params (opcionais):**
| Parametro | Tipo | Exemplo | Descricao |
|-----------|------|---------|-----------|
| regiao | string | `Sul` | Filtrar por regiao |
| uf | string | `RJ` | Filtrar por UF |
| status | string | `convertido` | Filtrar por status |
| minScore | number | `80` | Score minimo de qualificacao |
| search | string | `Buzios` | Busca por nome/cidade/email |

**Response:**
```json
{
  "leads": [...],
  "stats": {
    "total": 37,
    "porUf": [{"uf": "BA", "count": 3}],
    "porStatus": [{"status": "novo", "count": 10}],
    "porRegiao": [{"regiao": "Nordeste", "count": 12}],
    "avgScoreQual": 84,
    "avgScoreValid": 81
  }
}
```

### POST /api/leads
Criar novo lead. Body: campos do modelo Lead (exceto id, createdAt, updatedAt).

### PATCH /api/leads
Atualizar lead. Body: `{ id: "...", status: "contatado", ... }`

### DELETE /api/leads?id=xxx
Excluir lead por ID.

### GET /api/leads/analytics
Analytics detalhados: distribuicao por UF/regiao/status, score distribution,
atividade recente.

### POST /api/leads/seed
Seed via API. Body: `{ leads: [...] }` com array de objetos Lead.

---

## CAMPOS DO MODELO LEAD (Protocolo Secretaria-IA)

| Campo | Tipo | Obrigatorio | Descricao |
|-------|------|-------------|-----------|
| pousada | String | SIM | Nome do estabelecimento |
| email | String | SIM | E-mail de contato |
| whatsapp | String | SIM | Telefone WhatsApp (com DDI) |
| qtdQuartos | Int | NAO | Quantidade de quartos |
| localPraia | String | NAO | Localizacao especifica (praia/bairro) |
| cidade | String | SIM | Cidade |
| uf | String | SIM | Estado (sigla 2 letras) |
| valoresEstimados | String | NAO | Faixa de precos |
| qualificacao | String | NAO | Descricao qualitativa |
| validacao | String | NAO | pendente / validado |
| comportamentoCompra | String | NAO | Tradicional / Moderno / Elite |
| sinaisIntencao | String | NAO | Urgencias detectadas |
| redesSociais | String | NAO | Instagram handle |
| site | String | NAO | URL do site |
| telefone | String | NAO | Telefone fixo/alternativo |
| scoreQual | Int | NAO | Score de qualificacao (0-100) |
| scoreValid | Int | NAO | Score de validacao (0-100) |
| latitude | Float | SIM | Latitude (decimal) |
| longitude | Float | SIM | Longitude (decimal) |
| regiao | String | NAO | Regiao (auto-detectada pelo seed) |
| status | String | NAO | novo / contatado / respondido / convertido / perdido |
| observacoes | String | NAO | Notas internas |

---

## NOTAS IMPORTANTES

1. **SSR**: O componente LeadMap usa `dynamic import` com `ssr: false` porque 
   o Leaflet nao funciona no server-side. Se integrar como rota separada, 
   mantenha o dynamic import na pagina pai.

2. **CORS do TILE**: O CARTO dark tiles e gratuito e nao requer chave de API. 
   Se precisar de mais controle, use Mapbox (requer token pago).

3. **Clustering**: Para bases com 500+ leads, considere adicionar 
   `react-leaflet-cluster` para agrupar marcadores e nao travar o browser.

4. **Multi-tenant**: Se seu projeto ZEHLA usa isolamento multi-tenant via 
   Prisma Middleware, adicione `propertyId` ao modelo Lead e ajuste o 
   middleware para filtrar por propriedade.

5. **Dados**: O seed inclui 37 pousadas reais com coordenadas geograficas 
   reais. Substitua pelos seus proprios leads seguindo o protocolo acima.
