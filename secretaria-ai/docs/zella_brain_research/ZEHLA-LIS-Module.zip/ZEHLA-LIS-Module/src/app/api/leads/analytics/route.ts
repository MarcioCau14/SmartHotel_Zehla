import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const [leadsPorUf, leadsPorRegiao, leadsPorStatus, scoreDistribution, recentActivity] =
      await Promise.all([
        db.lead.groupBy({
          by: ['uf'],
          _count: true,
          _avg: { scoreQual: true, scoreValid: true },
          orderBy: { _count: { id: 'desc' } },
        }),
        db.lead.groupBy({
          by: ['regiao'],
          _count: true,
          _avg: { scoreQual: true, scoreValid: true },
        }),
        db.lead.groupBy({
          by: ['status'],
          _count: true,
        }),
        Promise.all([
          db.lead.count({ where: { scoreQual: { gte: 80 } } }),
          db.lead.count({ where: { scoreQual: { gte: 60, lt: 80 } } }),
          db.lead.count({ where: { scoreQual: { gte: 40, lt: 60 } } }),
          db.lead.count({ where: { scoreQual: { lt: 40 } } }),
        ]),
        db.lead.findMany({
          orderBy: { updatedAt: 'desc' },
          take: 10,
          select: {
            id: true,
            pousada: true,
            cidade: true,
            uf: true,
            status: true,
            scoreQual: true,
            updatedAt: true,
          },
        }),
      ]);

    const total = await db.lead.count();
    const avgScores = await db.lead.aggregate({
      _avg: { scoreQual: true, scoreValid: true },
    });

    return NextResponse.json({
      total,
      avgScoreQual: Math.round(avgScores._avg.scoreQual || 0),
      avgScoreValid: Math.round(avgScores._avg.scoreValid || 0),
      porUf: leadsPorUf.map(g => ({
        uf: g.uf,
        count: g._count.id,
        avgScore: Math.round(g._avg.scoreQual || 0),
      })),
      porRegiao: leadsPorRegiao.map(g => ({
        regiao: g.regiao,
        count: g._count.id,
        avgScore: Math.round(g._avg.scoreQual || 0),
      })),
      porStatus: leadsPorStatus.map(g => ({
        status: g.status,
        count: g._count.id,
      })),
      scoreDistribution: [
        { label: 'Excelente (80+)', count: scoreDistribution[0] },
        { label: 'Bom (60-79)', count: scoreDistribution[1] },
        { label: 'Regular (40-59)', count: scoreDistribution[2] },
        { label: 'Baixo (<40)', count: scoreDistribution[3] },
      ],
      recentActivity,
    });
  } catch (error) {
    console.error('Error fetching analytics:', error);
    return NextResponse.json({ error: 'Failed to fetch analytics' }, { status: 500 });
  }
}
