import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const body = await request.json();

    const regiaoMap: Record<string, string> = {
      'AC': 'Norte', 'AM': 'Norte', 'AP': 'Norte', 'PA': 'Norte', 'RO': 'Norte', 'RR': 'Norte', 'TO': 'Norte',
      'AL': 'Nordeste', 'BA': 'Nordeste', 'CE': 'Nordeste', 'MA': 'Nordeste', 'PB': 'Nordeste', 'PE': 'Nordeste', 'PI': 'Nordeste', 'RN': 'Nordeste', 'SE': 'Nordeste',
      'DF': 'Centro-Oeste', 'GO': 'Centro-Oeste', 'MS': 'Centro-Oeste', 'MT': 'Centro-Oeste',
      'ES': 'Sudeste', 'MG': 'Sudeste', 'RJ': 'Sudeste', 'SP': 'Sudeste',
      'PR': 'Sul', 'RS': 'Sul', 'SC': 'Sul',
    };

    for (const lead of body.leads) {
      const id = lead.id || `lead-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
      await db.lead.upsert({
        where: { id },
        update: lead,
        create: {
          ...lead,
          id,
          regiao: lead.regiao || regiaoMap[lead.uf] || 'Sudeste',
        },
      });
    }

    const total = await db.lead.count();
    return NextResponse.json({ success: true, total });
  } catch (error) {
    console.error('Error seeding leads:', error);
    return NextResponse.json({ error: 'Failed to seed leads' }, { status: 500 });
  }
}
