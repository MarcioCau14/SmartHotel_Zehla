import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const regiao = searchParams.get('regiao');
    const uf = searchParams.get('uf');
    const status = searchParams.get('status');
    const minScore = searchParams.get('minScore');
    const search = searchParams.get('search');

    const where: Record<string, unknown> = {};

    if (regiao && regiao !== 'todas') {
      where.regiao = regiao;
    }
    if (uf && uf !== 'todos') {
      where.uf = uf;
    }
    if (status && status !== 'todos') {
      where.status = status;
    }
    if (minScore) {
      where.scoreQual = { gte: parseInt(minScore) };
    }
    if (search) {
      where.OR = [
        { pousada: { contains: search } },
        { cidade: { contains: search } },
        { email: { contains: search } },
      ];
    }

    const leads = await db.lead.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    // Aggregate stats
    const totalLeads = await db.lead.count();
    const leadsPorUf = await db.lead.groupBy({
      by: ['uf'],
      _count: true,
      orderBy: { _count: { id: 'desc' } },
    });
    const leadsPorStatus = await db.lead.groupBy({
      by: ['status'],
      _count: true,
    });
    const leadsPorRegiao = await db.lead.groupBy({
      by: ['regiao'],
      _count: true,
    });
    const avgScoreQual = await db.lead.aggregate({
      _avg: { scoreQual: true },
    });
    const avgScoreValid = await db.lead.aggregate({
      _avg: { scoreValid: true },
    });

    return NextResponse.json({
      leads,
      stats: {
        total: totalLeads,
        porUf: leadsPorUf.map(g => ({ uf: g.uf, count: g._count.id })),
        porStatus: leadsPorStatus.map(g => ({ status: g.status, count: g._count.id })),
        porRegiao: leadsPorRegiao.map(g => ({ regiao: g.regiao, count: g._count.id })),
        avgScoreQual: Math.round(avgScoreQual._avg.scoreQual || 0),
        avgScoreValid: Math.round(avgScoreValid._avg.scoreValid || 0),
      },
    });
  } catch (error) {
    console.error('Error fetching leads:', error);
    return NextResponse.json({ error: 'Failed to fetch leads' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    const lead = await db.lead.create({
      data: {
        pousada: body.pousada,
        email: body.email,
        whatsapp: body.whatsapp,
        qtdQuartos: body.qtdQuartos,
        localPraia: body.localPraia,
        cidade: body.cidade,
        uf: body.uf,
        valoresEstimados: body.valoresEstimados,
        qualificacao: body.qualificacao,
        validacao: body.validacao || 'pendente',
        comportamentoCompra: body.comportamentoCompra,
        sinaisIntencao: body.sinaisIntencao,
        redesSociais: body.redesSociais,
        site: body.site,
        telefone: body.telefone,
        scoreQual: body.scoreQual || 0,
        scoreValid: body.scoreValid || 0,
        latitude: body.latitude,
        longitude: body.longitude,
        regiao: body.regiao,
        status: body.status || 'novo',
      },
    });

    return NextResponse.json(lead, { status: 201 });
  } catch (error) {
    console.error('Error creating lead:', error);
    return NextResponse.json({ error: 'Failed to create lead' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Lead ID is required' }, { status: 400 });
    }

    const lead = await db.lead.update({
      where: { id },
      data: {
        ...data,
        ultimoContato: data.status ? new Date() : data.ultimoContato ? new Date(data.ultimoContato) : undefined,
      },
    });

    return NextResponse.json(lead);
  } catch (error) {
    console.error('Error updating lead:', error);
    return NextResponse.json({ error: 'Failed to update lead' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Lead ID is required' }, { status: 400 });
    }

    await db.lead.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting lead:', error);
    return NextResponse.json({ error: 'Failed to delete lead' }, { status: 500 });
  }
}
