'use client';

import dynamic from 'next/dynamic';

const LeadMap = dynamic(() => import('@/components/leads/LeadMap'), {
  ssr: false,
  loading: () => (
    <div className="h-screen w-screen bg-[#0a0e1a] flex items-center justify-center">
      <div className="text-center">
        <div className="w-12 h-12 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-sm text-slate-400">Carregando ZEHLA LIS...</p>
        <p className="text-xs text-slate-600 mt-1">Lead Intelligence System</p>
      </div>
    </div>
  ),
});

export default function Home() {
  return <LeadMap />;
}
