'use client';

import { useState, useEffect, useCallback } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix Leaflet default icon issue with SVG markers
const defaultIcon = L.divIcon({
  html: `<svg width="28" height="36" viewBox="0 0 28 36" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M14 0C6.268 0 0 6.268 0 14c0 10.5 14 22 14 22s14-11.5 14-22C28 6.268 21.732 0 14 0z" fill="url(#grad)" stroke="#0f172a" stroke-width="1.5"/>
    <circle cx="14" cy="13" r="6" fill="white" opacity="0.9"/>
    <text x="14" y="16" text-anchor="middle" font-size="9" font-weight="bold" fill="#0f172a">&#9733;</text>
    <defs><linearGradient id="grad" x1="0" y1="0" x2="0" y2="36"><stop offset="0%" stop-color="#f59e0b"/><stop offset="100%" stop-color="#d97706"/></linearGradient></defs>
  </svg>`,
  className: 'lead-marker',
  iconSize: [28, 36],
  iconAnchor: [14, 36],
  popupAnchor: [0, -36],
});

const hotspotIcon = L.divIcon({
  html: `<svg width="32" height="40" viewBox="0 0 32 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16 0C7.164 0 0 7.164 0 16c0 12 16 24 16 24s16-12 16-24C32 7.164 24.836 0 16 0z" fill="url(#hgrad)" stroke="#0f172a" stroke-width="1.5"/>
    <circle cx="16" cy="15" r="7" fill="white" opacity="0.9"/>
    <text x="16" y="19" text-anchor="middle" font-size="11" font-weight="bold" fill="#dc2626">&#128293;</text>
    <defs><linearGradient id="hgrad" x1="0" y1="0" x2="0" y2="40"><stop offset="0%" stop-color="#ef4444"/><stop offset="100%" stop-color="#dc2626"/></linearGradient></defs>
  </svg>`,
  className: 'lead-marker-hot',
  iconSize: [32, 40],
  iconAnchor: [16, 40],
  popupAnchor: [0, -40],
});

const convertedIcon = L.divIcon({
  html: `<svg width="28" height="36" viewBox="0 0 28 36" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M14 0C6.268 0 0 6.268 0 14c0 10.5 14 22 14 22s14-11.5 14-22C28 6.268 21.732 0 14 0z" fill="url(#cgrad)" stroke="#0f172a" stroke-width="1.5"/>
    <circle cx="14" cy="13" r="6" fill="white" opacity="0.9"/>
    <text x="14" y="16" text-anchor="middle" font-size="9" font-weight="bold" fill="#059669">&#10003;</text>
    <defs><linearGradient id="cgrad" x1="0" y1="0" x2="0" y2="36"><stop offset="0%" stop-color="#10b981"/><stop offset="100%" stop-color="#059669"/></linearGradient></defs>
  </svg>`,
  className: 'lead-marker-conv',
  iconSize: [28, 36],
  iconAnchor: [14, 36],
  popupAnchor: [0, -36],
});

interface Lead {
  id: string;
  pousada: string;
  email: string;
  whatsapp: string;
  qtdQuartos: number | null;
  localPraia: string | null;
  cidade: string;
  uf: string;
  valoresEstimados: string | null;
  qualificacao: string | null;
  validacao: string;
  comportamentoCompra: string | null;
  sinaisIntencao: string | null;
  redesSociais: string | null;
  site: string | null;
  telefone: string | null;
  scoreQual: number;
  scoreValid: number;
  latitude: number;
  longitude: number;
  regiao: string | null;
  status: string;
  ultimoContato: string | null;
  observacoes: string | null;
}

interface Stats {
  total: number;
  porUf: { uf: string; count: number }[];
  porStatus: { status: string; count: number }[];
  porRegiao: { regiao: string; count: number }[];
  avgScoreQual: number;
  avgScoreValid: number;
}

function getLeadIcon(status: string, scoreQual: number) {
  if (status === 'convertido') return convertedIcon;
  if (scoreQual >= 85) return hotspotIcon;
  return defaultIcon;
}

function getScoreColor(score: number) {
  if (score >= 85) return 'text-green-400';
  if (score >= 70) return 'text-amber-400';
  if (score >= 50) return 'text-orange-400';
  return 'text-red-400';
}

function getStatusBadge(status: string) {
  const badges: Record<string, { label: string; className: string }> = {
    novo: { label: 'Novo', className: 'bg-slate-500/20 text-slate-300 border-slate-500/30' },
    contatado: { label: 'Contatado', className: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
    respondido: { label: 'Respondido', className: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
    convertido: { label: 'Convertido', className: 'bg-green-500/20 text-green-300 border-green-500/30' },
    perdido: { label: 'Perdido', className: 'bg-red-500/20 text-red-300 border-red-500/30' },
  };
  return badges[status] || badges.novo;
}

function MapController({ selectedLead }: { selectedLead: Lead | null }) {
  const map = useMap();
  useEffect(() => {
    if (selectedLead) {
      map.flyTo([selectedLead.latitude, selectedLead.longitude], 12, { duration: 1.5 });
    }
  }, [selectedLead, map]);
  return null;
}

function LeadPopup({ lead }: { lead: Lead }) {
  const whatsappClean = lead.whatsapp.replace(/\D/g, '');
  const whatsappLink = `https://wa.me/${whatsappClean}`;
  const emailLink = `mailto:${lead.email}`;
  const statusBadge = getStatusBadge(lead.status);

  return (
    <div className="min-w-[280px] max-w-[320px] font-sans">
      <div className="flex items-start justify-between gap-2 mb-3">
        <h3 className="text-sm font-bold text-slate-100 leading-tight">{lead.pousada}</h3>
        <span className={`text-[10px] px-2 py-0.5 rounded-full border whitespace-nowrap ${statusBadge.className}`}>
          {statusBadge.label}
        </span>
      </div>

      <div className="flex items-center gap-1.5 mb-2 text-slate-400 text-xs">
        <svg className="w-3 h-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
        <span>{lead.cidade}/{lead.uf}{lead.localPraia ? ` - ${lead.localPraia}` : ''}</span>
      </div>

      <div className="grid grid-cols-2 gap-2 mb-3">
        <div className="bg-slate-800/50 rounded-lg p-2 text-center">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider">Score Qual.</div>
          <div className={`text-lg font-bold ${getScoreColor(lead.scoreQual)}`}>{lead.scoreQual}</div>
        </div>
        <div className="bg-slate-800/50 rounded-lg p-2 text-center">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider">Score Valid.</div>
          <div className={`text-lg font-bold ${getScoreColor(lead.scoreValid)}`}>{lead.scoreValid}</div>
        </div>
      </div>

      <div className="space-y-1 mb-3 text-xs text-slate-400">
        {lead.qtdQuartos && (
          <div className="flex justify-between">
            <span>Quartos:</span><span className="text-slate-300">{lead.qtdQuartos}</span>
          </div>
        )}
        {lead.valoresEstimados && (
          <div className="flex justify-between">
            <span>Valores:</span><span className="text-slate-300">{lead.valoresEstimados}</span>
          </div>
        )}
        {lead.comportamentoCompra && (
          <div className="flex justify-between">
            <span>Perfil:</span><span className="text-slate-300">{lead.comportamentoCompra}</span>
          </div>
        )}
      </div>

      {lead.sinaisIntencao && (
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-2 mb-3">
          <div className="text-[10px] text-amber-400 uppercase tracking-wider mb-0.5">Sinais de Intencao</div>
          <div className="text-xs text-amber-200/80">{lead.sinaisIntencao}</div>
        </div>
      )}

      <div className="flex gap-2">
        <a
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-1.5 bg-green-600 hover:bg-green-500 text-white text-xs font-medium rounded-lg px-3 py-2 transition-colors"
        >
          <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
          WhatsApp
        </a>
        <a
          href={emailLink}
          className="flex-1 flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium rounded-lg px-3 py-2 transition-colors"
        >
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
          E-mail
        </a>
      </div>
    </div>
  );
}

export default function LeadMap() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<'map' | 'list' | 'analytics'>('map');
  const [filters, setFilters] = useState({
    regiao: 'todas',
    status: 'todos',
    search: '',
  });
  const [detailLead, setDetailLead] = useState<Lead | null>(null);

  const fetchLeads = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filters.regiao !== 'todas') params.set('regiao', filters.regiao);
      if (filters.status !== 'todos') params.set('status', filters.status);
      if (filters.search) params.set('search', filters.search);

      const res = await fetch(`/api/leads?${params.toString()}`);
      const data = await res.json();
      setLeads(data.leads || []);
      setStats(data.stats || null);
    } catch (err) {
      console.error('Failed to fetch leads:', err);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    fetchLeads();
  }, [fetchLeads]);

  const filteredLeads = leads;

  return (
    <div className="h-screen w-screen flex bg-[#0a0e1a] text-white overflow-hidden">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-80' : 'w-0'} transition-all duration-300 overflow-hidden flex-shrink-0 border-r border-slate-800/50`}>
        <div className="w-80 h-full flex flex-col bg-[#0d1117]">
          {/* Header */}
          <div className="p-4 border-b border-slate-800/50">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white text-xs font-bold">Z</div>
              <div>
                <h1 className="text-sm font-bold text-white">ZEHLA LIS</h1>
                <p className="text-[10px] text-slate-500">Lead Intelligence System</p>
              </div>
            </div>
            <div className="flex gap-1 bg-slate-900/50 rounded-lg p-0.5">
              {(['map', 'list', 'analytics'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 text-xs py-1.5 rounded-md transition-colors font-medium ${
                    activeTab === tab ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tab === 'map' ? 'Mapa' : tab === 'list' ? 'Lista' : 'Stats'}
                </button>
              ))}
            </div>
          </div>

          {/* Filters */}
          <div className="p-4 border-b border-slate-800/50 space-y-2">
            <div className="relative">
              <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
              <input
                type="text"
                placeholder="Buscar pousada, cidade..."
                value={filters.search}
                onChange={e => setFilters(f => ({ ...f, search: e.target.value }))}
                className="w-full bg-slate-900/50 border border-slate-700/50 rounded-lg pl-8 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500/50"
              />
            </div>
            <select
              value={filters.regiao}
              onChange={e => setFilters(f => ({ ...f, regiao: e.target.value }))}
              className="w-full bg-slate-900/50 border border-slate-700/50 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500/50"
            >
              <option value="todas">Todas as Regioes</option>
              <option value="Sul">Sul</option>
              <option value="Sudeste">Sudeste</option>
              <option value="Nordeste">Nordeste</option>
              <option value="Norte">Norte</option>
              <option value="Centro-Oeste">Centro-Oeste</option>
            </select>
            <select
              value={filters.status}
              onChange={e => setFilters(f => ({ ...f, status: e.target.value }))}
              className="w-full bg-slate-900/50 border border-slate-700/50 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500/50"
            >
              <option value="todos">Todos os Status</option>
              <option value="novo">Novo</option>
              <option value="contatado">Contatado</option>
              <option value="respondido">Respondido</option>
              <option value="convertido">Convertido</option>
              <option value="perdido">Perdido</option>
            </select>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {loading ? (
              <div className="flex items-center justify-center h-32">
                <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : activeTab === 'map' ? (
              <div className="p-4 space-y-2">
                <h3 className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">
                  Leads no Mapa ({filteredLeads.length})
                </h3>
                {filteredLeads.map(lead => (
                  <button
                    key={lead.id}
                    onClick={() => {
                      setSelectedLead(lead);
                      setDetailLead(lead);
                    }}
                    className={`w-full text-left p-2.5 rounded-lg border transition-all hover:border-amber-500/30 ${
                      selectedLead?.id === lead.id
                        ? 'bg-amber-600/10 border-amber-500/30'
                        : 'bg-slate-900/30 border-slate-800/50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-1">
                      <span className="text-xs font-medium text-slate-200 truncate">{lead.pousada}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full border whitespace-nowrap ${getStatusBadge(lead.status).className}`}>
                        {getStatusBadge(lead.status).label}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">{lead.cidade}/{lead.uf}</div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`text-[10px] font-medium ${getScoreColor(lead.scoreQual)}`}>
                        {lead.scoreQual >= 85 ? '🔥' : '★'} {lead.scoreQual}
                      </span>
                      {lead.sinaisIntencao && (
                        <span className="text-[10px] text-amber-500 truncate">⚡ {lead.sinaisIntencao}</span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            ) : activeTab === 'list' ? (
              <div className="p-4 space-y-1.5">
                <h3 className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">
                  Todos os Leads ({filteredLeads.length})
                </h3>
                {filteredLeads.map(lead => (
                  <div key={lead.id} className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/30 border border-slate-800/50 text-[10px]">
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${lead.scoreQual >= 85 ? 'bg-green-500' : lead.scoreQual >= 70 ? 'bg-amber-500' : 'bg-red-500'}`} />
                    <div className="flex-1 min-w-0">
                      <div className="text-slate-200 font-medium truncate">{lead.pousada}</div>
                      <div className="text-slate-500">{lead.cidade}/{lead.uf}</div>
                    </div>
                    <span className="text-slate-400">{lead.scoreQual}</span>
                  </div>
                ))}
              </div>
            ) : stats && (
              <div className="p-4 space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-800/50">
                    <div className="text-[10px] text-slate-500 uppercase tracking-wider">Total Leads</div>
                    <div className="text-xl font-bold text-white">{stats.total}</div>
                  </div>
                  <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-800/50">
                    <div className="text-[10px] text-slate-500 uppercase tracking-wider">Score Medio</div>
                    <div className={`text-xl font-bold ${getScoreColor(stats.avgScoreQual)}`}>{stats.avgScoreQual}</div>
                  </div>
                </div>
                <div>
                  <h4 className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Por Regiao</h4>
                  <div className="space-y-1.5">
                    {stats.porRegiao.map(r => (
                      <div key={r.regiao} className="flex items-center gap-2">
                        <span className="text-xs text-slate-300 w-24 truncate">{r.regiao || 'N/A'}</span>
                        <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-amber-600 to-orange-500 rounded-full"
                            style={{ width: `${stats.total ? (r.count / stats.total) * 100 : 0}%` }}
                          />
                        </div>
                        <span className="text-xs text-slate-400 w-6 text-right">{r.count}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Por Status</h4>
                  <div className="space-y-1">
                    {stats.porStatus.map(s => (
                      <div key={s.status} className="flex items-center justify-between text-xs">
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-full border ${getStatusBadge(s.status).className}`}>
                          {getStatusBadge(s.status).label}
                        </span>
                        <span className="text-slate-300 font-medium">{s.count}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Top UFs</h4>
                  <div className="space-y-1.5">
                    {stats.porUf.slice(0, 10).map(u => (
                      <div key={u.uf} className="flex items-center gap-2">
                        <span className="text-xs text-slate-400 w-8 font-mono">{u.uf}</span>
                        <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-blue-600 to-cyan-500 rounded-full"
                            style={{ width: `${stats.total ? (u.count / stats.total) * 100 : 0}%` }}
                          />
                        </div>
                        <span className="text-xs text-slate-400 w-6 text-right">{u.count}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          {stats && (
            <div className="p-3 border-t border-slate-800/50 bg-slate-900/30">
              <div className="flex items-center justify-between text-[10px]">
                <span className="text-slate-500">Exibindo: <span className="text-slate-300">{filteredLeads.length}</span> de {stats.total}</span>
                <span className="text-slate-500">Score Med: <span className={`font-medium ${getScoreColor(stats.avgScoreQual)}`}>{stats.avgScoreQual}</span></span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative">
        {/* Top Bar */}
        <div className="absolute top-0 left-0 right-0 z-[1000] p-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="bg-slate-900/80 backdrop-blur-md border border-slate-700/50 rounded-lg p-2 hover:bg-slate-800/80 transition-colors"
              >
                <svg className="w-4 h-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/></svg>
              </button>
              <div className="bg-slate-900/80 backdrop-blur-md border border-slate-700/50 rounded-lg px-3 py-2">
                <span className="text-xs text-slate-300">
                  <span className="text-amber-400 font-bold">{filteredLeads.length}</span> leads mapeados
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {['Sul', 'Sudeste', 'Nordeste', 'Norte', 'Centro-Oeste'].map(regiao => (
                <button
                  key={regiao}
                  onClick={() => setFilters(f => ({ ...f, regiao: f.regiao === regiao ? 'todas' : regiao }))}
                  className={`text-[10px] px-2.5 py-1.5 rounded-lg border backdrop-blur-md transition-all ${
                    filters.regiao === regiao
                      ? 'bg-amber-600/90 border-amber-500 text-white'
                      : 'bg-slate-900/80 border-slate-700/50 text-slate-400 hover:text-white'
                  }`}
                >
                  {regiao}
                </button>
              ))}
              <div className="bg-slate-900/80 backdrop-blur-md border border-slate-700/50 rounded-lg px-3 py-2 hidden lg:flex items-center gap-3">
                <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-green-500" /><span className="text-[10px] text-slate-400">Conv.</span></div>
                <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-red-500" /><span className="text-[10px] text-slate-400">Hot</span></div>
                <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-amber-500" /><span className="text-[10px] text-slate-400">Outros</span></div>
              </div>
            </div>
          </div>
        </div>

        {/* Map View */}
        {activeTab === 'map' ? (
          <MapContainer
            center={[-14.235, -51.9253]}
            zoom={5}
            className="h-full w-full"
            zoomControl={false}
            style={{ background: '#0a0e1a' }}
          >
            <TileLayer
              attribution='&copy; <a href="https://carto.com/">CARTO</a>'
              url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            />
            <MapController selectedLead={selectedLead} />
            {filteredLeads.map(lead => (
              <Marker
                key={lead.id}
                position={[lead.latitude, lead.longitude]}
                icon={getLeadIcon(lead.status, lead.scoreQual)}
                eventHandlers={{ click: () => setDetailLead(lead) }}
              >
                <Popup>
                  <LeadPopup lead={lead} />
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        ) : activeTab === 'list' ? (
          <div className="h-full overflow-y-auto p-6">
            <div className="max-w-5xl mx-auto">
              <h2 className="text-lg font-bold text-white mb-4">Lista Completa de Leads</h2>
              <div className="bg-[#0d1117] rounded-xl border border-slate-800/50 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs min-w-[700px]">
                    <thead>
                      <tr className="border-b border-slate-800/50">
                        <th className="text-left p-3 text-slate-500 font-medium">Pousada</th>
                        <th className="text-left p-3 text-slate-500 font-medium">Cidade</th>
                        <th className="text-left p-3 text-slate-500 font-medium">UF</th>
                        <th className="text-left p-3 text-slate-500 font-medium">Score</th>
                        <th className="text-left p-3 text-slate-500 font-medium">Status</th>
                        <th className="text-left p-3 text-slate-500 font-medium">Acoes</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredLeads.map(lead => (
                        <tr key={lead.id} className="border-b border-slate-800/30 hover:bg-slate-800/20 transition-colors">
                          <td className="p-3 text-slate-200 font-medium">{lead.pousada}</td>
                          <td className="p-3 text-slate-400">{lead.cidade}</td>
                          <td className="p-3 text-slate-400">{lead.uf}</td>
                          <td className="p-3"><span className={`font-bold ${getScoreColor(lead.scoreQual)}`}>{lead.scoreQual}</span></td>
                          <td className="p-3">
                            <span className={`text-[10px] px-2 py-0.5 rounded-full border ${getStatusBadge(lead.status).className}`}>
                              {getStatusBadge(lead.status).label}
                            </span>
                          </td>
                          <td className="p-3">
                            <div className="flex gap-1">
                              <a href={`https://wa.me/${lead.whatsapp.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded bg-green-600/20 text-green-400 hover:bg-green-600/30 transition-colors">
                                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/></svg>
                              </a>
                              <a href={`mailto:${lead.email}`} className="p-1.5 rounded bg-blue-600/20 text-blue-400 hover:bg-blue-600/30 transition-colors">
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                              </a>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Analytics View */
          <div className="h-full overflow-y-auto p-6">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-lg font-bold text-white mb-4">Analytics Dashboard</h2>
              {stats && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-[#0d1117] rounded-xl border border-slate-800/50 p-5">
                    <h3 className="text-xs text-slate-500 uppercase tracking-wider mb-4">Distribuicao por Regiao</h3>
                    <div className="space-y-3">
                      {stats.porRegiao.map(r => (
                        <div key={r.regiao}>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-slate-300">{r.regiao || 'N/A'}</span>
                            <span className="text-slate-500">{r.count} leads ({stats.total ? Math.round((r.count / stats.total) * 100) : 0}%)</span>
                          </div>
                          <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-amber-600 to-orange-500 rounded-full" style={{ width: `${stats.total ? (r.count / stats.total) * 100 : 0}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-[#0d1117] rounded-xl border border-slate-800/50 p-5">
                    <h3 className="text-xs text-slate-500 uppercase tracking-wider mb-4">Funil de Conversao</h3>
                    <div className="space-y-2">
                      {stats.porStatus.map((s, i) => {
                        const colors = ['bg-slate-500', 'bg-blue-500', 'bg-purple-500', 'bg-green-500', 'bg-red-500'];
                        return (
                          <div key={s.status}>
                            <div className="flex justify-between text-xs mb-1">
                              <span className="text-slate-300">{getStatusBadge(s.status).label}</span>
                              <span className="text-slate-500">{s.count}</span>
                            </div>
                            <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
                              <div className={`h-full ${colors[i]} rounded-full`} style={{ width: `${Math.max(stats.total ? (s.count / stats.total) * 100 : 0, 2)}%` }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <div className="bg-[#0d1117] rounded-xl border border-slate-800/50 p-5 md:col-span-2">
                    <h3 className="text-xs text-slate-500 uppercase tracking-wider mb-4">Top 10 UFs por Volume</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {stats.porUf.slice(0, 10).map((u, i) => (
                        <div key={u.uf} className="flex items-center gap-3 p-2 rounded-lg bg-slate-900/30">
                          <span className="text-xs font-bold text-amber-400 w-5">#{i + 1}</span>
                          <span className="text-sm font-mono text-slate-300 w-8">{u.uf}</span>
                          <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-blue-600 to-cyan-500 rounded-full" style={{ width: `${stats.total ? (u.count / stats.total) * 100 : 0}%` }} />
                          </div>
                          <span className="text-xs text-slate-400 w-6 text-right">{u.count}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Detail Panel */}
        {detailLead && (
          <div className="absolute bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-[380px] z-[1000]">
            <div className="bg-[#0d1117]/95 backdrop-blur-md border border-slate-700/50 rounded-xl p-4 shadow-2xl">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-sm font-bold text-white">{detailLead.pousada}</h3>
                  <p className="text-xs text-slate-400">{detailLead.cidade}/{detailLead.uf} {detailLead.localPraia ? `- ${detailLead.localPraia}` : ''}</p>
                </div>
                <button onClick={() => setDetailLead(null)} className="text-slate-500 hover:text-white transition-colors">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
              </div>
              <div className="grid grid-cols-3 gap-2 mb-3">
                <div className="bg-slate-900/50 rounded-lg p-2 text-center">
                  <div className="text-[10px] text-slate-500">Score Qual.</div>
                  <div className={`text-lg font-bold ${getScoreColor(detailLead.scoreQual)}`}>{detailLead.scoreQual}</div>
                </div>
                <div className="bg-slate-900/50 rounded-lg p-2 text-center">
                  <div className="text-[10px] text-slate-500">Score Valid.</div>
                  <div className={`text-lg font-bold ${getScoreColor(detailLead.scoreValid)}`}>{detailLead.scoreValid}</div>
                </div>
                <div className="bg-slate-900/50 rounded-lg p-2 text-center">
                  <div className="text-[10px] text-slate-500">Status</div>
                  <div className="mt-0.5">
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full border ${getStatusBadge(detailLead.status).className}`}>
                      {getStatusBadge(detailLead.status).label}
                    </span>
                  </div>
                </div>
              </div>
              {detailLead.qualificacao && <p className="text-xs text-slate-400 mb-2 leading-relaxed">{detailLead.qualificacao}</p>}
              {detailLead.sinaisIntencao && (
                <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-2 mb-3">
                  <div className="text-[10px] text-amber-400 font-medium mb-0.5">Sinais de Intencao</div>
                  <p className="text-xs text-amber-200/80">{detailLead.sinaisIntencao}</p>
                </div>
              )}
              <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                {detailLead.email && <div className="text-slate-400 truncate"><span className="text-slate-500">Email: </span><span className="text-slate-300">{detailLead.email}</span></div>}
                {detailLead.telefone && <div className="text-slate-400"><span className="text-slate-500">Tel: </span><span className="text-slate-300">{detailLead.telefone}</span></div>}
                {detailLead.qtdQuartos && <div className="text-slate-400"><span className="text-slate-500">Quartos: </span><span className="text-slate-300">{detailLead.qtdQuartos}</span></div>}
                {detailLead.valoresEstimados && <div className="text-slate-400"><span className="text-slate-500">Valores: </span><span className="text-slate-300">{detailLead.valoresEstimados}</span></div>}
                {detailLead.comportamentoCompra && <div className="text-slate-400"><span className="text-slate-500">Perfil: </span><span className="text-slate-300">{detailLead.comportamentoCompra}</span></div>}
                {detailLead.validacao && <div className="text-slate-400"><span className="text-slate-500">Validacao: </span><span className={detailLead.validacao === 'validado' ? 'text-green-400' : 'text-orange-400'}>{detailLead.validacao}</span></div>}
              </div>
              <div className="flex gap-2">
                {detailLead.whatsapp && (
                  <a href={`https://wa.me/${detailLead.whatsapp.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 text-white text-xs font-medium rounded-lg px-4 py-2.5 transition-colors">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/></svg>
                    WhatsApp
                  </a>
                )}
                {detailLead.email && (
                  <a href={`mailto:${detailLead.email}`} className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium rounded-lg px-4 py-2.5 transition-colors">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                    E-mail
                  </a>
                )}
                {detailLead.redesSociais && (
                  <a href={`https://instagram.com/${detailLead.redesSociais.replace('@', '')}`} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-xs font-medium rounded-lg px-4 py-2.5 transition-colors">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
                  </a>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
